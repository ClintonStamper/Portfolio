<?php

define('__ROOT__', getcwd()); 
require_once(__ROOT__.'/includes/config.php');
require_once(__ROOT__.'/includes/json.php');

$result = false;

if(isset($_GET['userid'])){
		$userid = strval($_GET['userid']);

		if(!is_null($userid)){
			$query = "SELECT notifications FROM " . USER_SETTINGS_DATABASE_NAME . " WHERE user_id='" . $userid . "'";

			$res = mysqli_query($db, $query);
			if($res){
				$resObject = mysqli_fetch_assoc($res);
				if($resObject){
					$result = intval($resObject['notifications']);
				}
			}
		}else{
			die("Something was null");
		}
}else{
	die("You didn't specify the URL correctly");
}


echo json_encode($result);
?>