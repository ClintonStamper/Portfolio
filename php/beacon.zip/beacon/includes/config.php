<?php
define('__ROOTCONFIG__', getcwd()); 
require_once(__ROOTCONFIG__.'/includes/constants.php'); 



$db = new mysqli(SERVER_NAME, SERVER_USERNAME, SERVER_PASSWORD, SERVER_DATABASE_NAME);

if($db->connect_error){
	die("Connection failed: " . $db->connect_error);
}
?>