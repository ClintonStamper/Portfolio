<?php


define('BASE_URL', 'http://www.cswebdeign.biz/beacon');
define('SERVER_NAME', 'localhost');
define('SERVER_USERNAME', 'clinton_beacon');
define('SERVER_PASSWORD', 'pHg.B];+yVek1*Hkm,');
define('SERVER_DATABASE_NAME', 'clinton_beacon');

define('BLOCKED_USER_DATABASE_NAME', 'blocked_users');
define('USER_INFO_DATABASE_NAME', 'users');
define('USER_SETTINGS_DATABASE_NAME', 'user_settings');
define('PREFERRED_FRIENDS_DATABASE_NAME', 'preferred_friends');
define('RECENT_MATCHES_DATABASE_NAME', 'recently_matched');
define('GROUP_DATABASE_NAME', 'current_groups');
?>