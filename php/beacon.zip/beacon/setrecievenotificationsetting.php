<?php

define('__ROOT__', getcwd()); 
require_once(__ROOT__.'/includes/config.php');
require_once(__ROOT__.'/includes/json.php');

$result = false;

if(isset($_GET['userid']) AND isset($_GET['setvalue'])){
		$userid = strval($_GET['userid']);
		$setValue = intval($_GET['setvalue']);

		if(!is_null($userid) AND !is_null($setValue)){
			$query = "UPDATE " . USER_SETTINGS_DATABASE_NAME . " SET notifications=" . $setValue . " WHERE user_id='" . $userid . "'";

			$res = mysqli_query($db, $query);
			if($res){
				$result = $res;
			}
		}else{
			die("Something was null");
		}
}else{
	die("You didn't specify the URL correctly");
}


echo json_encode($result);
?>