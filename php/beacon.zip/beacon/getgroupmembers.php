<?php
define('__ROOT__', getcwd()); 
require_once(__ROOT__.'/includes/config.php');
require_once(__ROOT__.'/includes/json.php');

$result = array();

if(isset($_GET['userid'])){
		$userid = strval($_GET['userid']);

		if(!is_null($userid)){
			$query = "Select users FROM " . GROUP_DATABASE_NAME . " WHERE users LIKE '%," . $userid . "%' OR users LIKE '%" . $userid . ",%'";

			$res = mysqli_query($db, $query);

			if($res){
				while($row = mysqli_fetch_assoc($res)) {
					$result[] = $row;
				}
			}
		}else{
			die("Something was null");
		}
}else{
	die("You didn't specify the URL correctly");
}


echo json_encode($result);
?>