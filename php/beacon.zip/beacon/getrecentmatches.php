<?php
define('__ROOT__', getcwd()); 
require_once(__ROOT__.'/includes/config.php');
require_once(__ROOT__.'/includes/json.php');

$result = array();

if(isset($_GET['userid'])){
		$userid = strval($_GET['userid']);

		if(!is_null($userid)){
			$query = "Select * FROM " . RECENT_MATCHES_TABLE . " WHERE origin_user_id='" . $userid . "'" ;

			echo $query;

			$res = mysqli_query($db, $query);

			if($res){
				while($row = mysqli_fetch_assoc($res)) {
					$result[] = $row;
				}
			}
		}else{
			die("Something was null");
		}
}else{
	die("You didn't specify the URL correctly");
}


echo json_encode($result);
?>