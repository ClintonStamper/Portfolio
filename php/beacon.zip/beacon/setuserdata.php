<?php

define('__ROOT__', getcwd()); 
require_once(__ROOT__.'/includes/config.php');
require_once(__ROOT__.'/includes/json.php');

$result = false;

if(isset($_GET['userid']) AND isset($_GET['firstname']) AND isset($_GET['lastname']) AND isset($_GET['photourl'])){
		$userid = strval($_GET['userid']);
		$firstName = strval($_GET['firstname']);
		$lastName = strval($_GET['lastname']);
		$photoURL = strval($_GET['photourl']);

		if(!is_null($userid) AND !is_null($firstName) AND !is_null($lastName) AND !is_null($photoURL)){
			$query1 = "INSERT INTO " . USER_INFO_DATABASE_NAME . " (user_id, first_name, last_name, photo_location) VALUES ('" . $userid . "', '" . $firstName . "', '" . $lastName . "', '" . $photoURL . "')";

			$res1 = mysqli_query($db, $query1);

			$query2 = "INSERT INTO " . USER_SETTINGS_DATABASE_NAME . " (user_id) VALUES ('" . $userid . "')";

			$res2 = mysqli_query($db, $query2);

			if($res1 AND $res2){
				$result = $res1 AND $res2;
			}
		}else{
			die("Something was null");
		}
}else{
	die("You didn't specify the URL correctly");
}


echo json_encode($result);
?>