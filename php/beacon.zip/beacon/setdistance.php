<?php

define('__ROOT__', getcwd()); 
require_once(__ROOT__.'/includes/config.php');
require_once(__ROOT__.'/includes/json.php');

$result = false;

if(isset($_GET['userid']) AND isset($_GET['distance'])){
		$userid = strval($_GET['userid']);
		$distance = intval($_GET['distance']);

		if(!is_null($userid) AND !is_null($distance)){
			$query = "UPDATE " . USER_SETTINGS_DATABASE_NAME . " SET distance=" . $distance . " WHERE user_id='" . $userid . "'";

			$res = mysqli_query($db, $query);
			if($res){
				$result = $res;
			}
		}else{
			die("Something was null");
		}
}else{
	die("You didn't specify the URL correctly");
}


echo json_encode($result);
?>