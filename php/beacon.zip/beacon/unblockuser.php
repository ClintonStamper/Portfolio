<?php

define('__ROOT__', getcwd()); 
require_once(__ROOT__.'/includes/config.php');
require_once(__ROOT__.'/includes/json.php');

$result = false;

if(isset($_GET['userid']) AND isset($_GET['unblockid'])){
		$userid = strval($_GET['userid']);
		$unblockid = strval($_GET['unblockid']);

		$endOfStatement = " FROM " . BLOCKED_USER_DATABASE_NAME . " WHERE origin_user_id='" . $userid . "' AND blocked_user_id='" . $unblockid . "'";

		$querySELECT = "SELECT *" . $endOfStatement; 

		$resSELECT = mysqli_query($db, $querySELECT);

		if($resSELECT){

			$numRows = intval(mysqli_num_rows($resSELECT));
			if($numRows > 0){
				$queryDELETE = "DELETE" . $endOfStatement;

				echo "Statement: " . $queryDELETE;

				$resDELETE = mysqli_query($db, $queryDELETE);

				$result = false;

				if($resDELETE){
					$result = $res;
				}
			}else{
				$result = true;
			}
		}else{
			
		}
}else{
	die("You didn't specify the URL correctly");
}


echo json_encode($result, JSON_PRETTY_PRINT);
?>