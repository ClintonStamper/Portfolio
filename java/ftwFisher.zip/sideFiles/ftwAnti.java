package scripts.fisher.sideFiles;

import org.tribot.api.input.Mouse;
import org.tribot.api.interfaces.Clickable07;
import org.tribot.api.util.abc.ABCProperties;
import org.tribot.api.util.abc.ABCUtil;
import org.tribot.api.util.abc.preferences.OpenBankPreference;
import org.tribot.api.util.abc.preferences.TabSwitchPreference;
import org.tribot.api.util.abc.preferences.WalkingPreference;
import org.tribot.api2007.Banking;
import org.tribot.api2007.Combat;
import org.tribot.api2007.Game;
import org.tribot.api2007.Player;
import org.tribot.api2007.types.RSNPC;
import org.tribot.api2007.types.RSTile;

/**
 * @author Worthy
 */
public class ftwAnti {

	private final ABCUtil abcUtil;

	private boolean shouldHover = false;
	private boolean shouldOpenMenu = false;

	private int HPPercentToEatAt = -1;
	private int RunEnergyPercentToTurnOn = -1;

	private RSNPC nextTarget = null;

	public ftwAnti() {
		abcUtil = new ABCUtil();
		generateGetHPToEatAtPercent();
		generateGetRunActivatePercent();
		generateNewTargetVariables();
	}

	/**
	 * To perform when idling
	 */
	public void run(int estimatedWaitTime, RSNPC[] possibleTargets) {
		if(estimatedWaitTime > 0){
			abcUtil.generateTrackers(abcUtil.generateBitFlags(estimatedWaitTime));
		}
		if (!Banking.isBankScreenOpen() && !Banking.isPinScreenOpen() && !Banking.isPinMessageOpen()) {
			performTimedActions();
		}
		if(possibleTargets != null){
			if(possibleTargets.length > 0){
				checkForCloserTarget(possibleTargets);
			}
		}
	}

	public void run() {
		run(-1, null);
	}


	/**
	 * 
	 * @param possibleTargets
	 * @return
	 */
	public void selectNextTarget(RSNPC[] possibleTargets) {
		this.nextTarget = (RSNPC) abcUtil.selectNextTarget(possibleTargets);
	}

	public RSNPC getNextTarget(){
		return nextTarget;
	}

	/**
	 * 
	 * @return
	 */
	public OpenBankPreference getBankPref(){
		return abcUtil.generateOpenBankPreference();
	}

	/**
	 * 
	 * @return
	 */
	public TabSwitchPreference getTabPref(){
		return abcUtil.generateTabSwitchPreference();
	}

	/**
	 * 
	 * @param distance
	 * @return
	 */
	public WalkingPreference getWalkPref(int distance){
		return abcUtil.generateWalkingPreference(distance);
	}

	/**
	 * 
	 * @param percentHP
	 * @return
	 */
	public boolean shouldEat(){
		int percentHP = Combat.getHPRatio();
		if(percentHP != -1){
			if(percentHP < HPPercentToEatAt){
				generateGetHPToEatAtPercent();
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 * @param percentRun
	 * @return
	 */
	public boolean turnOnRun(){
		int percentRun = Game.getRunEnergy();
		if(percentRun != -1){
			if(percentRun < RunEnergyPercentToTurnOn){
				generateGetRunActivatePercent();
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 * @return
	 */
	public boolean shouldMoveToAnticipatedLocation(){
		return abcUtil.shouldMoveToAnticipated();
	}

	/**
	 * 
	 * @param competitionCount
	 * @return
	 */
	public boolean shouldSwitchResources(int competitionCount){
		return abcUtil.shouldSwitchResources(competitionCount);
	}

	/**
	 * 
	 */
	public void newTargetObtained(RSNPC[] possibleNextTargets){
		selectNextTarget(possibleNextTargets);
		generateNewTargetVariables();
		performTargetMethods();
	}

	/**
	 * 
	 */
	public void performTargetMethods() {
		if(nextTarget != null){
			if(nextTarget instanceof Clickable07){
				Clickable07 targetClickable = (Clickable07) nextTarget;
				if(targetClickable != null){
					if(shouldHoverNextTarget()){
						if(targetClickable.hover()){
							if(shouldOpenMenu()){
								Mouse.click(3);
							}
						}
					}
				}
			}
		}
	}

	public void sleepReactionTime(int timeWaitedToPerformAction, boolean justInCombat){
		ABCProperties abcUtilProperties = abcUtil.getProperties();
		abcUtilProperties.setHovering(shouldHover);
		abcUtilProperties.setMenuOpen(shouldHover && shouldOpenMenu);
		abcUtilProperties.setUnderAttack(justInCombat || Combat.isUnderAttack());
		abcUtilProperties.setWaitingFixed(false);
		abcUtilProperties.setWaitingTime(timeWaitedToPerformAction);
		abcUtil.setProperties(abcUtilProperties);

		int sleepTime = abcUtil.generateReactionTime();

		try {
			abcUtil.sleep(sleepTime);
		} catch (InterruptedException e) {
		}
	}









	//PRIVATE METHODS

	private void performTimedActions() {
		if(abcUtil.shouldCheckTabs()){
			abcUtil.checkTabs();
		}
		if(abcUtil.shouldCheckXP()){
			abcUtil.checkXP();
		}
		if(abcUtil.shouldExamineEntity()){
			abcUtil.examineEntity();
		}
		if(abcUtil.shouldLeaveGame()){
			abcUtil.leaveGame();
		}
		if(abcUtil.shouldMoveMouse()){
			abcUtil.moveMouse();
		}
		if(abcUtil.shouldPickupMouse()){
			abcUtil.pickupMouse();
		}
		if(abcUtil.shouldRightClick()){
			abcUtil.rightClick();
		}
		if(abcUtil.shouldRotateCamera()){
			abcUtil.rotateCamera();
		}
	}

	private void checkForCloserTarget(RSNPC[] possibleTargets) {
		boolean newTarget = false;
		if(nextTarget != null){
			RSTile playerPos = Player.getPosition();
			if(playerPos != null){
				int distanceToBeat = playerPos.distanceTo(nextTarget);
				for(RSNPC possibleTarget : possibleTargets){
					int currentDistance = playerPos.distanceTo(possibleTarget);
					if(currentDistance < distanceToBeat){
						newTarget = true;
						break;
					}
				}
			}
		}else{
			newTargetObtained(possibleTargets);
		}
		if(newTarget){
			newTargetObtained(possibleTargets);
		}
	}

	private void generateGetHPToEatAtPercent(){
		this.HPPercentToEatAt = abcUtil.generateEatAtHP();
	}

	private void generateGetRunActivatePercent(){
		this.RunEnergyPercentToTurnOn = abcUtil.generateRunActivation();
	}

	private void generateShouldHoverNextTarget(){
		this.shouldHover = abcUtil.shouldHover();
	}

	private void generateShouldOpenMenu(){
		this.shouldOpenMenu = abcUtil.shouldOpenMenu();
	}

	private boolean shouldHoverNextTarget(){
		return Mouse.isInBounds() && shouldHover;
	}

	private boolean shouldOpenMenu(){
		return Mouse.isInBounds() && shouldHover && shouldOpenMenu;
	}

	private void generateNewTargetVariables() {
		generateShouldHoverNextTarget();
		generateShouldOpenMenu();
	}

	public void resetSpot() {
		this.nextTarget = null;
		
	}
}