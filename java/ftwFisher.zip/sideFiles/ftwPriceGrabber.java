package scripts.fisher.sideFiles;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

import scripts.fisher.gui.GUITools;

public class ftwPriceGrabber {
	

	private static final String signifyPrice = "{\"overall\":";
	private static final String seperator = ",";

	public static final int getPrice(int id){
		
		int result = -1;

		try{
			String urlToQueryString = "https://api.rsbuddy.com/grandExchange?a=guidePrice&i=" + id;
			URL urlToQuery = new URL(urlToQueryString);
			InputStream stream = urlToQuery.openStream();
			InputStreamReader streamReader = new InputStreamReader(stream);
			BufferedReader reader = new BufferedReader(streamReader);
			String input = GUITools.readAll(reader);
			String[] inputParts = input.split(seperator);
			for(String s : inputParts){
				if(s.contains(signifyPrice)){
					s = s.substring(s.indexOf(signifyPrice) + signifyPrice.length());
					result = Integer.parseInt(s);
					break;
				}else{
				}
			}
		}catch (Exception e){

		}



		return result;
	}

}
