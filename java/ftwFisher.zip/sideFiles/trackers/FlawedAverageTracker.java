package scripts.fisher.sideFiles.trackers;

public class FlawedAverageTracker {
		double currentAverage = 0;
		int numbersAddedCount = 0;
		
		
		public FlawedAverageTracker(){
			
		}
		
		public void addNumber(double numberToAdd){
			currentAverage = (currentAverage * numbersAddedCount + numberToAdd) / (numbersAddedCount + 1);
		}
		
		public double getCurrentAverage(){
			return currentAverage;
		}
		
		public int getNumberOfNumbersAddedCount(){
			return numbersAddedCount;
		}

}
