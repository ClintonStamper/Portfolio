package scripts.fisher.sideFiles.trackers;


//Used to keep track of fish caught by the script
	public class CatchTracker {
		
		/*
		 * Variables for each catch tracker
		 * Caught: total fish caught
		 * LastUpdate: used to only send newly caught fish to the server
		 */
		
		private int caught;
		private int lastUpdate;
		
		
		//Initializing catchTracker
		public CatchTracker(){
			this.caught = 0;
			this.lastUpdate = 0;
		}
		
		//Adds a fish to the counter
		public void addCaught(){
			this.caught++;
		}
		
		//returns only the fish caught since the last update
		public int update(){
			int result = this.caught - this.lastUpdate;
			this.lastUpdate = this.caught;
			return result;
		}
		
		//returns the total amount caught
		public int getCaught(){
			return this.caught;
		}
	
	}