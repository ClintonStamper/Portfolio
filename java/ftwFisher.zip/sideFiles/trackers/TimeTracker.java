package scripts.fisher.sideFiles.trackers;

import org.tribot.api.Timing;

public class TimeTracker {
		private long start;
		public TimeTracker() {this.start = System.currentTimeMillis();}
		public void reset() {this.start = System.currentTimeMillis();}
		public long getElapsed() {return (Timing.timeFromMark(start));}
	}