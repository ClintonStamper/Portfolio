package scripts.fisher.sideFiles.trackers;

import org.tribot.api2007.Skills;
import org.tribot.api2007.Skills.SKILLS;

//Tracker class to keep track of experience gained
	public class ExperienceTracker {
		
		/*
		 * Variables for each Experience Tracker
		 * skill:  The skill that you are tracking
		 * startExperience:  The experience the skill started at
		 * updateExperience:  The amount of experience at the last update
		 */
		
		private SKILLS skill;
		private int startExperience;
		private int updateExperience;
		
		//Initializing Experience Tracker using the skill you want to track
		public ExperienceTracker(SKILLS skillChoice) {
			this.skill = skillChoice;
			this.startExperience = Skills.getXP(this.skill);
			this.updateExperience = Skills.getXP(this.skill);
		}
		
		//Returns the total amount of experience gained since the start
		public long getGained() {return (Skills.getXP(this.skill) - this.startExperience);}
		
		//Returns the amount of experience gained since the last time the function was called.
		public int getUpdateGained() {
			int result = Skills.getXP(this.skill) - this.updateExperience;
			this.updateExperience = Skills.getXP(this.skill);
			return result;
		}
		
		//Resets the amount of experience gained 
		public void reset() {this.startExperience = Skills.getXP(this.skill);
		this.updateExperience = Skills.getXP(this.skill);}
	}