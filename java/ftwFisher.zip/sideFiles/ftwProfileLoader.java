package scripts.fisher.sideFiles;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

import org.tribot.util.Util;

import scripts.fisher.classes.NonProgressiveProfileInformation;
import scripts.fisher.gui.GUITools;

public class ftwProfileLoader {

	private final String systemLocation;
	private final String urlLocation;
	private final String tribotUsername;

	private NonProgressiveProfileInformation[] nonProgressiveProfiles = {};

	public ftwProfileLoader(String tribotUsername) {
		this.systemLocation = Util.getWorkingDirectory() + File.separator + "ftwfisher" + File.separator + "profiles";
		this.urlLocation = "http://www.ftwscripting.com/ftwfisher/profiles";
		this.tribotUsername = tribotUsername;
	}

	public void loadProfiles(){
		this.nonProgressiveProfiles = loadUserProfiles();
	}

	public NonProgressiveProfileInformation[] loadUserProfiles(){
		NonProgressiveProfileInformation[] result = {};

		String urlForProfiles = urlLocation + "/" + "profilelist.php?username=" + tribotUsername;
		URL urlToVisit = GUITools.convertToURLEscapingIllegalCharacters(urlForProfiles);

		try {
			InputStream stream = urlToVisit.openStream();
			InputStreamReader streamReader = new InputStreamReader(stream);
			BufferedReader reader = new BufferedReader(streamReader);
			String unFormattedList = GUITools.readAll(reader);

			String[] profileList = unFormattedList.split("<br />");

			if(profileList.length > 0){
				downloadProfiles(profileList);
				result = loadProfiles(profileList);
			}

			stream.close();
		} catch (IOException e) {
		}


		return result;
	}

	private NonProgressiveProfileInformation[] loadProfiles(String[] profileList) {
		ArrayList<NonProgressiveProfileInformation> profiles = new ArrayList<>();
		for(String profile : profileList){
			String[] partsOfProfile = profile.split(",");
			if(partsOfProfile.length == 2){
				NonProgressiveProfileInformation toAdd = loadProfile(partsOfProfile);
				if(toAdd != null){
					profiles.add(toAdd);
				}
			}
		}
		return profiles.toArray(nonProgressiveProfiles);
	}

	private NonProgressiveProfileInformation loadProfile(String[] partsOfProfile) {
		NonProgressiveProfileInformation result = null;

		String fileName = partsOfProfile[0] + partsOfProfile[1] + ".txt";
		String filePathToReadFrom = systemLocation + File.separator + tribotUsername + File.separator + fileName;

		File fileToReadFrom = new File(filePathToReadFrom);

		if(fileToReadFrom.exists()){
			String location = null;
			String equiptment = null;
			String lootList = null;
			int bankOption = -1;
			try {
				Scanner input = new Scanner(fileToReadFrom);
				while(input.hasNextLine()){
					String current = input.nextLine();
					if(current.equalsIgnoreCase("location_name")){
						if(input.hasNextLine()){
							location = input.nextLine();
						}
					}
					if(current.equalsIgnoreCase("equiptment_name")){
						if(input.hasNextLine()){
							equiptment = input.nextLine();
						}
					}
					if(current.equalsIgnoreCase("loot_list")){
						if(input.hasNextLine()){
							lootList = input.nextLine();
						}
					}
					if(current.equalsIgnoreCase("bank_option")){
						if(input.hasNextLine()){
							bankOption = Integer.parseInt(input.nextLine());
						}
					}
				}
				input.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(location != null && equiptment != null && lootList != null && bankOption > -1){
				String[] lootListArray = lootList.contains(",") ? lootList.split(",") : new String[] {lootList};
				result = new NonProgressiveProfileInformation(location, equiptment, lootListArray, bankOption, partsOfProfile[0]);
			}
		}

		return result;
	}

	private void downloadProfiles(String[] profileList) {
		for(String profile : profileList){
			String[] partsOfProfile = profile.split(",");
			if(partsOfProfile.length == 2){
				if(!profileExistsAndIsUpdated(partsOfProfile)){
					downloadProfile(partsOfProfile);
				}
			}
		}
	}

	private void downloadProfile(String[] partsOfProfile) {
		String urlToReadFromString = urlLocation + "/" + "getprofile.php?username=" + tribotUsername + "&profile_name=" + partsOfProfile[0];
		URL urlToReadFrom = GUITools.convertToURLEscapingIllegalCharacters(urlToReadFromString);
		try{
			InputStream stream = urlToReadFrom.openStream();
			InputStreamReader streamReader = new InputStreamReader(stream);
			BufferedReader reader = new BufferedReader(streamReader);
			String unFormattedList = GUITools.readAll(reader);

			String[] linesToWrite = unFormattedList.split("<br />");


			String fileName = partsOfProfile[0] + partsOfProfile[1] + ".txt";
			String filePathToWriteTo = systemLocation + File.separator + tribotUsername + File.separator + fileName;

			File fileToWriteTo = new File(filePathToWriteTo);
			fileToWriteTo.getParentFile().mkdirs();

			PrintWriter writer = new PrintWriter(fileToWriteTo);
			for(String lineToWrite : linesToWrite){
				writer.println(lineToWrite);
			}
			writer.close();
			stream.close();
		}catch (Exception e){

		}
	}

	private boolean profileExistsAndIsUpdated(String[] partsOfProfile) {
		String fileName = partsOfProfile[0] + partsOfProfile[1] + ".txt";
		String userSystemLocation = systemLocation + File.separator + tribotUsername + File.separator + fileName;
		File fileToTry = new File(userSystemLocation);
		if(!fileToTry.exists()){
			userSystemLocation = userSystemLocation.replaceAll(fileName, "");
			File dirToSearch = new File(userSystemLocation);
			File[] filesInDir = dirToSearch.exists() ? dirToSearch.listFiles() : null;
			if(filesInDir != null){
				for(File fileInDir : filesInDir){
					if(fileInDir.isFile()){
						String name = fileInDir.getName();
						if(name.contains(partsOfProfile[0])){
							if(name.replaceAll(partsOfProfile[0], "").replaceAll(".txt", "").matches("\\d+")){
								fileInDir.delete();
							}
						}
					}
				}
			}
		}
		return fileToTry.exists();
	}

	public void saveProfile(NonProgressiveProfileInformation profileToSave){
		String urlToSendToString = urlLocation + "/" + "addprofile.php?username=" + tribotUsername + "&profile_name=" + profileToSave.getProfileName() + "&location_name=" + profileToSave.getAreaName() + "&equiptment_name=" + profileToSave.getEquiptmentName() + "&loot_list=" + profileToSave.getLossListFormatted() + "&bank_option=" + profileToSave.getBankOption(); 
		URL urlToSendTo = GUITools.convertToURLEscapingIllegalCharacters(urlToSendToString);
		try{
			InputStream stream = urlToSendTo.openStream();
			stream.close();
		}catch(Exception e){
		}
		loadProfiles();
	}

	public void deleteProfile(NonProgressiveProfileInformation profileToDelete){
		if(profileToDelete != null){
			String urlToSendToString = urlLocation + "/" + "deleteprofile.php?username=" + tribotUsername + "&profile_name=" + profileToDelete.getProfileName(); 
			URL urlToSendTo = GUITools.convertToURLEscapingIllegalCharacters(urlToSendToString);

			String fileLocation = systemLocation + File.separator + tribotUsername + File.separator;

			File dirToSearch = new File(fileLocation);
			File[] filesInDir = dirToSearch.exists() ? dirToSearch.listFiles() : null;
			if(filesInDir != null){
				for(File fileInDir : filesInDir){
					if(fileInDir.isFile()){
						String name = fileInDir.getName();
						if(name.contains(profileToDelete.getProfileName())){
							if(name.replaceAll(profileToDelete.getProfileName(), "").replaceAll(".txt", "").matches("\\d+")){
								fileInDir.delete();
							}
						}
					}
				}
			}

			try{
				InputStream stream = urlToSendTo.openStream();
				stream.close();
			}catch(Exception e){
			}
			loadProfiles();
		}
	}

	public NonProgressiveProfileInformation[] getProfiles() {
		return nonProgressiveProfiles;
	}
}
