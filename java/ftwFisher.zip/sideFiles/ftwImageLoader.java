package scripts.fisher.sideFiles;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;

public class ftwImageLoader {
	private final String baseURLDir;
	private final String baseSystemDir;
	
	private String localSystemDir;
	private String localURLDir;
	
	public ftwImageLoader(String baseURL, String baseSystemDir){
		this.baseURLDir = baseURL;
		this.baseSystemDir = baseSystemDir;
	}
	
	public Image getImage(String fileString){
		Image result = null;
		String localDir = baseSystemDir + File.separator + localSystemDir + File.separator + fileString;
		File file = new File(localDir);
		result = getImageLocally(file);
		if(result == null){
			String urlString = baseURLDir + "/" + localURLDir + "/" + fileString;
			try {
				URL url = new URL(urlString);
				BufferedImage bufferedResult = ImageIO.read(url);
				if(bufferedResult != null){
					file.mkdirs();
					String type = localDir.substring(localDir.lastIndexOf('.')+1);
					ImageIO.write(bufferedResult, type, file);
					result = bufferedResult;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	
	private Image getImageLocally(File file) {
		Image result = null;
		if(file.exists()){
			try {
				result = ImageIO.read(file);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	public String getBaseSystemDir() {
		return baseSystemDir;
	}

	public String getBaseURL() {
		return baseURLDir;
	}

	public String getLocalDir() {
		return localSystemDir;
	}

	public void setLocalDir(String localDir) {
		this.localSystemDir = localDir;
	}

	public String getLocalURLDir() {
		return localURLDir;
	}

	public void setLocalURLDir(String localURLDir) {
		this.localURLDir = localURLDir;
	}

	public void saveImageFromWeb(String fileString) {
		String urlString = baseURLDir + "/" + localURLDir + "/" + fileString;
		String localDir = baseSystemDir + File.separator + localSystemDir + File.separator + fileString;
		Image result = null;
		File file = new File(localDir);
		result = getImageLocally(file);
		if(result == null){
			try {
				URL url = new URL(urlString);
				BufferedImage bufferedResult = ImageIO.read(url);
				if(bufferedResult != null){
					file.mkdirs();
					String type = localDir.substring(localDir.lastIndexOf('.')+1);
					ImageIO.write(bufferedResult, type, file);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
