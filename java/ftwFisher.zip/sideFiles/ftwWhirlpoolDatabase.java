package scripts.fisher.sideFiles;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;

import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api2007.Skills.SKILLS;
import org.tribot.script.Script;

import scripts.fisher.ftwFisher;
import scripts.fisher.sideFiles.trackers.CatchTracker;
import scripts.fisher.sideFiles.trackers.ExperienceTracker;
import scripts.fisher.sideFiles.trackers.TimeTracker;

public class ftwWhirlpoolDatabase extends Script {

	private TimeTracker updateTime = new TimeTracker();
	public TimeTracker timeRunning = new TimeTracker();

	public ExperienceTracker tracker = new ExperienceTracker(SKILLS.FISHING);

	public CatchTracker catchTracker = new CatchTracker();

	//creates a new instance of this class with the passed in ftwFisher
	public ftwWhirlpoolDatabase(ftwFisher ftwFisher) {
	}

	@Override
	public void run() {
			if(updateTime.getElapsed() > 300000){
				sendUpdate();
				updateTime.reset();
			}
	}

	//Checks to see if the interacting index of the player is equal to the index of any fishing spot and then makes sure that it is not a fishingspot that we want
//	private boolean interactingWithWhirlpool() {
//		RSPlayer player = Player.getRSPlayer();
//		if(player != null){
//			int index = player.getInteractingIndex();
//			if(index != -1){
//				RSNPC[] npcs = NPCs.find("Fishing spot");
//				for(int i = 0 ; i < npcs.length ; i++){
//					RSNPC npc = npcs[i];
//					if(npc != null){
//						int npcIndex = npc.getIndex();
//						if(npcIndex != -1){
//							if(npcIndex == index){
//								int id = npc.getID();
//								if(id != -1){
//									if(id != fisher.fishingSpotId)return true;
//								}
//							}
//						}
//					}
//				}
//			}
//		}
//		return false;
//	}
//
//	//moves the character away from the fishing position
//	private void avoidWhirlpool() {
//		RSTile position = Player.getPosition();
//		if(position != null){
//			Walking.walkScreenPath(Walking.randomizePath(Walking.generateStraightScreenPath(position),3,3));
//		}
//
//	}

	private String username = General.getTRiBotUsername();

	private void sendUpdate() {
		int runtime = (Math.round(updateTime.getElapsed()/60000));
		int xp = tracker.getUpdateGained();
		int caught = catchTracker.update();
		try {
			URL url;            
			url = new URL("http://cswebdesign.biz/scripts/updater.php?username="+username+"&runtime="+runtime+"&exp="+xp+"&caught="+caught);
			URLConnection con = url.openConnection();
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		println("Updated Signature, You earned " + formatNumber(xp) + " Expeience in " + Timing.msToString(runtime * 60000) + " while catching " + caught + " fish.");
	}

	public String perHour(int gained, long elapsed) {
		return formatNumber((int) ((gained) * 3600000D / elapsed));
	}

	public String formatNumber(int start) {
		DecimalFormat nf = new DecimalFormat("0.0");
		double i = start;
		if(i >= 1000000) {
			return nf.format((i / 1000000)) + "m";
		}
		if(i >=  1000) {
			return nf.format((i / 1000)) + "k";
		}
		return ""+start;
	}


}
