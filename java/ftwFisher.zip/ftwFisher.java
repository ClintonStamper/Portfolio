package scripts.fisher;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import org.tribot.api.DynamicClicking;
import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.input.DynamicMouse;
import org.tribot.api.input.Keyboard;
import org.tribot.api.input.Mouse;
import org.tribot.api.interfaces.Positionable;
import org.tribot.api.types.generic.Condition;
import org.tribot.api.types.generic.CustomRet_0P;
import org.tribot.api.types.generic.Filter;
import org.tribot.api.util.Screenshots;
import org.tribot.api.util.abc.preferences.WalkingPreference;
import org.tribot.api2007.Banking;
import org.tribot.api2007.Camera;
import org.tribot.api2007.ChooseOption;
import org.tribot.api2007.Game;
import org.tribot.api2007.GameTab;
import org.tribot.api2007.GameTab.TABS;
import org.tribot.api2007.GroundItems;
import org.tribot.api2007.Interfaces;
import org.tribot.api2007.Inventory;
import org.tribot.api2007.Login;
import org.tribot.api2007.Login.STATE;
import org.tribot.api2007.NPCChat;
import org.tribot.api2007.NPCs;
import org.tribot.api2007.Objects;
import org.tribot.api2007.PathFinding;
import org.tribot.api2007.Player;
import org.tribot.api2007.Skills;
import org.tribot.api2007.Skills.SKILLS;
import org.tribot.api2007.Walking;
import org.tribot.api2007.WebWalking;
import org.tribot.api2007.ext.Ships;
import org.tribot.api2007.types.RSArea;
import org.tribot.api2007.types.RSCharacter;
import org.tribot.api2007.types.RSGroundItem;
import org.tribot.api2007.types.RSInterface;
import org.tribot.api2007.types.RSItem;
import org.tribot.api2007.types.RSItemDefinition;
import org.tribot.api2007.types.RSNPC;
import org.tribot.api2007.types.RSNPCDefinition;
import org.tribot.api2007.types.RSObject;
import org.tribot.api2007.types.RSObjectDefinition;
import org.tribot.api2007.types.RSPlayer;
import org.tribot.api2007.types.RSTile;
import org.tribot.script.Script;
import org.tribot.script.interfaces.Ending;
import org.tribot.script.interfaces.EventBlockingOverride;
import org.tribot.script.interfaces.MessageListening07;
import org.tribot.script.interfaces.Painting;

import scripts.fisher.classes.NonProgressiveProfile;
import scripts.fisher.classes.fishingArea;
import scripts.fisher.classes.fishingBait;
import scripts.fisher.classes.fishingEquiptment;
import scripts.fisher.classes.fishingItem;
import scripts.fisher.classes.fishingLoot;
import scripts.fisher.gui.GUIManager;
import scripts.fisher.sideFiles.ftwAnti;
import scripts.fisher.sideFiles.ftwWhirlpoolDatabase;
import scripts.fisher.sideFiles.ftwWorldHopper;
import scripts.fisher.sideFiles.trackers.FlawedAverageTracker;
import scripts.fisher.sideFiles.trackers.TimeTracker;

public class ftwFisher extends Script implements Painting, MessageListening07, Ending, EventBlockingOverride{

	/*
	UPDATES
	improved bin shilo
	 */

	//BOOLEANS
	static public boolean isScriptPremium;

	//Switch for other programs to pause script
	public static boolean waitForOutside = false;

	//current spot
	private NonProgressiveProfile currentProfile = null;

	//Used to see if script should stop, and exit loop
	public boolean stop = false;

	//Used to tell if spot was added to the possible list of locations for future spots
	private boolean loggedSpot = false;

	//STRINGS
	final public static String username = General.getTRiBotUsername().replace(" ", "_");

	//USERSPECIFIC VARS
	private String rsUsername = "";
	// name = {human mean, human sd}
	private double[] tryMeanSD = {9, 2};
	private double[] sleepMeanSD = {575, 150};
	private double[] baitMeanSD = {1500, 500};
	public double[] breakMeanSD = {1000,200};


	//INTS 
	private int BAIT_AMOUNT = 25;
	private int coinCheck = 0;


	//Trackers
	private boolean interactingWithSpot = false;
	private boolean wasInCombat = false;
	private final TimeTracker timeSpentFishing = new TimeTracker();
	private final FlawedAverageTracker averageTimeSpentFishing = new FlawedAverageTracker();

	private boolean wasSailingLastChecked = false;
	private final TimeTracker timeSpentSailing = new TimeTracker();
	private final FlawedAverageTracker averageTimeSpentSailing = new FlawedAverageTracker();



	final private RSArea guildRoom = new RSArea (new RSTile[] { new RSTile(2617, 3393, 0), new RSTile(2604, 3393, 0), new RSTile(2604, 3397, 0), new RSTile(2607, 3397, 0), new RSTile(2607, 3399, 0) , new RSTile(2617, 3399, 0)});


	private final RSArea karamjaIslandArea =  new RSArea(new RSTile[] { 
			new RSTile(2891, 3178, 0), 
			new RSTile(2895, 3180, 0), 
			new RSTile(2901, 3183, 0), 
			new RSTile(2911, 3182, 0), 
			new RSTile(2918, 3182, 0), 
			new RSTile(2925, 3184, 0), 
			new RSTile(2932, 3180, 0), 
			new RSTile(2938, 3166, 0), 
			new RSTile(2947, 3161, 0), 
			new RSTile(2952, 3158, 0), 
			new RSTile(2953, 3162, 0), 
			new RSTile(2956, 3158, 0), 
			new RSTile(2956, 3153, 0), 
			new RSTile(2960, 3152, 0), 
			new RSTile(2965, 3147, 0), 
			new RSTile(2965, 3144, 0), 
			new RSTile(2949, 3144, 0), 
			new RSTile(2945, 3140, 0), 
			new RSTile(2939, 3137, 0), 
			new RSTile(2929, 3142, 0), 
			new RSTile(2918, 3142, 0), 
			new RSTile(2905, 3136, 0), 
			new RSTile(2893, 3140, 0), 
			new RSTile(2886, 3158, 0)
	});
	private final RSTile karamjaBoatToIsland = new RSTile(3028,3221,0);
	private final RSTile karamjaIslandToBoat = new RSTile(2954,3147,0);

	//CUSTOM OBJECTS

	private ftwAnti anti;
	private ftwWhirlpoolDatabase whirlPool;
	private final ArrayList<RSTile> possibleSpots = new ArrayList<RSTile>();



	//Options for traveling to karamja
	private final String[] possibleChatOptions = {"Can I journey on this ship?", "Search away, I have nothing to hide.", "Ok.", "Yes please.", "I'd like to access my bank account, please."};
	private final String[] continueMessagesToIgnore = {"You can't carry any more", "arrives at Karamja", "level"};


	private boolean wasChattingLastChecked = false;
	//
	/**
	 * Click the chat if a new level is achieved.
	 * CHECKED 8-26-15
	 */
	private boolean handleChat() {
		boolean result = true;
		if(wasChattingLastChecked){
			Timing.waitCondition(new Condition() {

				@Override
				public boolean active() {
					return NPCChat.getClickContinueInterface() != null || (NPCChat.getOptions() != null && NPCChat.getOptions().length > 0);
				}
			}, randomSD(250,750,500,100));
		}
		//Checks to see if the message is for a new level, if it is then it takes a screenshot, if not it clicks continue
		if(NPCChat.getClickContinueInterface() != null){
			String message = NPCChat.getMessage();
			if(message != null){
				if(message.contains("level")){
					try{
						Screenshots.take();
					} catch(Exception e){
						e.printStackTrace();
					}
				}
				if(!isStringContainedInArrayOfStrings(message, continueMessagesToIgnore)){
					result = false;
					NPCChat.clickContinue(true);
				}
			}
		}else if(NPCChat.getOptions() != null){
			for(String s : possibleChatOptions){
				if(NPCChat.selectOption(s, true)){
					result = false;
					break;
				}
			}

		}
		while(Ships.isSailing()){
			anti.run(7000, null);
			Timing.waitCondition(new Condition() {

				@Override
				public boolean active() {
					anti();
					return Objects.findNearest(10, 2084, 2082).length != 0;
				}
			}, General.randomSD(2500, 250));
		}
		wasChattingLastChecked = !result;
		return result;
	}

	/**
	 * Logs out the account and makes sure that the bank and pin screen are closed
	 * CHECKED 8-26-15
	 */
	public  void logOut() {status = "Logging out";
	while(Login.getLoginState() != STATE.LOGINSCREEN && Player.getRSPlayer() != null && !Player.getRSPlayer().isInCombat()){
		if(Banking.close() && Banking.closePinMessage()){
			Login.logout();
		}
	}		
	}

	/**
	 * Determines if the player is ready to bank
	 * @return	whether the inventory is full or not and if the player needs bait.
	 * CHECKED 8-26-15
	 */
	private boolean readyToBankOrDiscard() {
		return Inventory.isFull() || needBait();
	}

	/**
	 * Determines if the player needs any bait
	 * @return whether there is any bait in the inventory.
	 */
	private boolean needBait() {
		boolean result = false;
		if(currentProfile != null){
			fishingEquiptment currentEquiptment = currentProfile.getEquiptment();
			if(currentEquiptment != null){
				fishingBait[] baits = currentEquiptment.getBaits();
				if(baits != null){
					for(fishingBait bait : baits){
						int id = bait.getId();
						result = result || Inventory.getCount(id) == 0;
					}
				}
			}
		}
		return result;
	}

	/**n
	 * Opens the premium thread if they are trying to access a premium option
	 * CHECKED 8-26-15
	 */
	private void openPremiumThread() {status = "GIVE ME MONEY";
	println("Opening Premium WebSite");
	paint = getPaint("http://www.ftwscripting.com/ftwfisher/paint/freemium.png");
	println("we will be logging you out and opening the premium script's purchase page, if you would like to remain logged in please stop the script now.");
	for(int i = 5 ; i >= 0 ; i--){
		sleep(1000);
		println("~Proceeding in " + i + " seconds to logout.");
	}
	URI uri = URI.create("https://tribot.org/repository/script/id/200-new-ftwaio-fisher/");
	try {
		Desktop desktop = Desktop.getDesktop();
		desktop.browse(uri);
	} catch (IOException e) {
		e.printStackTrace();
		println("Fishing " + fishing + " at " + location + " is a premium feature.");
		println("If you would like to purchase the premium version of the script please visit https://tribot.org/repository/script/id/200-new-ftwaio-fisher/ ");
	}

	//Stopping the script
	logOut();
	stop = true;
	}

	/**
	 * Runs the GUI to get all input from user
	 * CHECKED 8-26-15
	 */
	private void runGUI() {status = "Showing GUI";
	GUIManager manager = new GUIManager();
	manager.run();
	currentProfile = GUIManager.profileServer;
	GUIManager.profileServer = null;
	}

	/**
	 * Determines if the player is ready to fish
	 * @return	true if the player's inventory is not full, he has the right equipment, is not approaching a fishing spot and is in the fishingArea.
	 * CHECKED 9-05-15
	 */
	private boolean readyToFish() {
		boolean result = false;
		if(currentProfile != null){
			fishingEquiptment currentEquipt = currentProfile.getEquiptment();
			if(currentEquipt != null){
				if(currentEquipt.carryingItemAndBaits()){
					boolean interactingWithFishingSpot = InteractingWithFishingSpot("fishing spot");
					if(!interactingWithFishingSpot || playerIsDoingNothing()){
						sleepFishingReactionTime();
						if(!Inventory.isFull() ||  playerWillHaveInventorySpot()){
							fishingArea currentArea = currentProfile.getArea();
							if(currentArea != null){
								RSArea fishingArea = currentArea.getFishArea();
								if(fishingArea != null){
									if(PlayerIsInArea(fishingArea) || DestinationIsInArea(fishingArea)){
										result = true;
									}else{
										walkToFishingArea();
									}
								}
							}
						}
					}else{
						if(interactingWithFishingSpot){
							if(!interactingWithSpot){
								timeSpentFishing.reset();
								interactingWithSpot = true;
							}
							RSNPC[] npcs = getPossibleSpots(false);
							anti.run(-1, npcs);
						}
						if(!loggedSpot){
							checkSpotAndAdd();
							loggedSpot = true;
						}
					}
				}else{
					getEquiptment();
				}
			}
		}
		return result;
	}

	private boolean DestinationIsInArea(RSArea Area) {
		boolean result = false;
		RSTile destination = Game.getDestination();
		if(destination != null){
			result = closeToArea(destination, Area, 5);
		}
		return result;
	}

	private boolean PlayerIsInArea(RSArea Area) {
		boolean result = false;
		RSTile position = Player.getPosition();
		if(position != null){
			result = closeToArea(position, Area, 5);
		}
		return result;
	}

	private boolean playerIsDoingNothing() {		
		return Player.getAnimation() == -1 && !Player.isMoving();
	}

	/**
	 * Determines if the player is interacting an Entity with the given name.
	 * @param entityName Name of entity, case insensitive
	 * @return true if interacting with an entity with the given param.
	 */
	private boolean InteractingWithFishingSpot(String entityName) {
		boolean result = false;
		String interactingEntityName = getInteractingObjectName();
		if(interactingEntityName != null){
			result = interactingEntityName.equalsIgnoreCase(entityName);
		}
		return result;
	}

	/**
	 * Determines if the player will have a fishing spot for the next caught fish.
	 * @return	true if there will be a spot available
	 * CHECKED 9-05-15
	 */
	private boolean playerWillHaveInventorySpot() {
		RSItem[] baitItems = Inventory.find(new Filter<RSItem>(){

			@Override
			public boolean accept(RSItem item) {
				boolean result = false;
				if(item != null){
					RSItemDefinition def = item.getDefinition();
					if(def != null){
						int itemID = def.getID();
						if(itemID != -1){
							if(currentProfile != null){
								fishingEquiptment currentEquiptment = currentProfile.getEquiptment();
								if(currentEquiptment != null){
									fishingBait[] currentBaits = currentEquiptment.getBaits();
									if(currentBaits != null){
										for(fishingBait currentBait : currentBaits){
											if(currentBait != null){
												int baitID = currentBait.getId();
												if(baitID != -1){
													result = result || itemID == baitID;
												}
											}
										}
									}
								}
							}
						}
					}
				}
				return result;
			}

		});

		for(RSItem item : baitItems){
			int stackCount = item.getStack();
			if(stackCount == 1){
				return true;
			}
		}
		return false;
	}

	/**
	 * Adds a fishing spot to the list of possible spots, where player is standing
	 * CHECKED 9-05-15
	 */
	private void checkSpotAndAdd() {
		RSTile position = Player.getPosition();
		if(position != null){
			if(!possibleSpots.contains(position)){
				possibleSpots.add(position);
			}
		}		
	}


	/**
	 * Walks to the fishing area
	 * CHECKED 9-05-15
	 */
	private void walkToFishingArea() {status = "Walking to Spot";
	if(currentProfile != null){
		fishingArea area = currentProfile.getArea();
		if(area != null){
			RSArea fishingArea = area.getFishArea();
			RSArea walkingArea = area.getWalkArea();
			if(fishingArea != null && walkingArea != null){
				if(!fishingAtKaramja()){
					walkToArea(fishingArea, walkingArea);
				}else{
					sailingReactionTime();
					walkToKaramjaFishingArea();
				}
			}
		}
	}
	}

	private void sailingReactionTime() {
		boolean isSailing = Ships.isSailing();
		if(isSailing){
			if(!wasSailingLastChecked){
				timeSpentSailing.reset();
			}
		}else{
			if(wasSailingLastChecked){
				long timeSpentSailingThisTime = timeSpentSailing.getElapsed();
				averageTimeSpentSailing.addNumber(timeSpentSailingThisTime);
				anti.sleepReactionTime((int) averageTimeSpentSailing.getCurrentAverage(), wasInCombat);
				wasInCombat = false;
			}
		}
		wasSailingLastChecked = isSailing;
	}

	private void walkToArea(RSArea areaToWalkTo, RSArea constraintArea){
		if(areaToWalkTo != null){
			RSTile walkTile = areaToWalkTo.getRandomTile();
			RSTile destination = Game.getDestination();
			RSPlayer player = Player.getRSPlayer();
			if(walkTile != null && player != null){
				if(destination == null || closeToArea(player, areaToWalkTo, 4)){
					if(closeToArea(player, constraintArea, 10)){
						if(destination == null || destination.distanceTo(player) < randomSD(1, 5, 2, 1)){
							aStarWalk(walkTile, areaToWalkTo, constraintArea.polygon);
						}
					}else{
						walkBack(areaToWalkTo);
					}
				}
			}
		}
	}

	private void walkToKaramjaFishingArea() {
		if(Inventory.getCount("Coins") >= 30 || Ships.isOnShip()){
			coinCheck = 0;
			if(karamjaIslandArea.contains(Player.getRSPlayer())){
				if(currentProfile != null){
					fishingArea currentArea = currentProfile.getArea();
					if(currentArea != null){
						RSArea fishingArea = currentArea.getFishArea();
						if(fishingArea != null){
							WebWalking(fishingArea.getRandomTile());
						}
					}
				}
			}else{
				if(!Ships.isOnShip()){
					clickCaptainKaramja(karamjaBoatToIsland);
				}else{
					Ships.crossGangplank();
				}
			}
		}else{
			if(coinCheck > 10){
				logOut();
				stop = true;
				println("You are out of coins for taking the boat");
			}else if(!Ships.isSailing()){
				println("You are not sailing and don't appear to have coins");
				sleepSD();
				coinCheck++;
			}
		}

	}

	private void clickCaptainKaramja(RSTile positionOfCaptains){
		Positionable player = Player.getRSPlayer();
		if(player != null){
			RSTile pos = player.getPosition();
			if(pos != null){
				if(pos.distanceTo(positionOfCaptains) > 10){
					RSTile dest = Game.getDestination();
					if(dest != null && dest.distanceTo(positionOfCaptains) <= 10){
						RSNPC[] nearestCaptain = NPCs.findNearest("Seaman Thresnor", "Captain Tobias", "Seaman Lorris", "Customs officer");
						if(nearestCaptain.length > 0){
							RSNPC captain = nearestCaptain[0];
							while(captain.isValid() && dest != null && dest.distanceTo(nearestCaptain[0]) <= 10){
								Positionable turnToTile = randomizeTile(captain, 2, 2);
								Camera.turnToTile(turnToTile);
							}
						}
					}else{
						WebWalking(positionOfCaptains);
					}
				}
				if(pos.distanceTo(positionOfCaptains)<= 10){
					RSNPC[] nearestCaptain = NPCs.findNearest("Seaman Thresnor", "Captain Tobias", "Seaman Lorris", "Customs officer");
					if(nearestCaptain.length > 0){
						RSNPC captain = nearestCaptain[0];
						if(captain.isOnScreen()){
							if(captain.isClickable()){
								if(captain.isValid()){
									DynamicClicking.clickRSNPC(captain, "Pay-Fare");
								}
							}
						}else{
							Camera.turnToTile(randomizeTile(captain, 2, 2));
						}
					}
				}
			}
		}
	}

	private void walkToKaramjaBankingArea() {
		if(Inventory.getCount("Coins") >= 30 || Ships.isOnShip()){
			if(!karamjaIslandArea.contains(Player.getRSPlayer())){
				if(!Ships.isOnShip()){
					if(currentProfile != null){
						fishingArea area = currentProfile.getArea();
						if(area != null){
							RSArea bankingArea = area.getBankArea();
							if(bankingArea != null){
								WebWalking(bankingArea.getRandomTile());
							}
						}
					}
				}else{
					Ships.crossGangplank();
				}
			}else{
				if(handleChat()){
					clickCaptainKaramja(karamjaIslandToBoat);
				}
			}
		}else{
			if(!Ships.isSailing()){
				logOut();
				stop = true;
				println("You are out of coins for taking the boat");
			}
		}

	}

	private void walkBack(RSArea areaToWalkTo) {status = "We're So Lost";
	RSPlayer player = Player.getRSPlayer();
	if(player != null){
		WebWalking(areaToWalkTo.getRandomTile());
	}
	}

	private void WebWalking(Positionable destination) {
		WebWalking.walkTo(destination);		
	}

	private void getEquiptment() {status = "Getting Gear";
	if(currentProfile != null){
		fishingEquiptment currentEquiptment = currentProfile.getEquiptment();
		if(currentEquiptment != null){
			if(!needBait()){
				pickupEquiptmentOffGround(currentEquiptment);
				if(!currentEquiptment.carryingItemAndBaits()){
					bank(true);
				}
			}
		}
	}
	}

	private void pickupEquiptmentOffGround(fishingItem currentEquiptment) { status = "YOU DROPPED IT!";
	RSGroundItem[] fishingEquiptmentOnGround = GroundItems.findNearest(currentEquiptment.getId());
	if(fishingEquiptmentOnGround != null){
		if(fishingEquiptmentOnGround.length > 0){
			for(int i = (int) randomSD(0, fishingEquiptmentOnGround.length - 1, 0 , 1); i < fishingEquiptmentOnGround.length && !currentEquiptment.carryingItem(); i++){
				RSGroundItem fishingItem = fishingEquiptmentOnGround[i];
				int tryAmount = randomSD(1,15, tryMeanSD[0], tryMeanSD[1]);
				for(int x = 0 ; x < tryAmount && !currentEquiptment.carryingItem(); x++){
					if(PathFinding.canReach(fishingItem, false) || !guildRoom.contains(fishingItem)){
						if(fishingItem.isOnScreen()){
							tryToPickupItem(currentEquiptment, fishingItem);
						}else{
							RSTile positionOfPlayer = Player.getPosition();
							if(positionOfPlayer != null){
								if(anti.getWalkPref(positionOfPlayer.distanceTo(fishingItem)) == WalkingPreference.MINIMAP){
									walkPath(Walking.generateStraightPath(fishingItem));
									tryToPickupItemWhileWalking(currentEquiptment, fishingItem);
								}else{
									walkScreenPath(Walking.generateStraightScreenPath(fishingItem));
									tryToPickupItemWhileWalking(currentEquiptment, fishingItem);
								}
							}
						}
					}else{
						bank(true);
					}
				}
			}
		}
	}
	}

	private void tryToPickupItemWhileWalking(fishingItem currentEquiptment, RSGroundItem fishingItem) {
		while(Player.isMoving()){
			if(fishingItem.isOnScreen()){
				tryToPickupItem(currentEquiptment, fishingItem);
			}else{
				Camera.turnToTile(randomizeTile(fishingItem, 3, 3));
				sleepSD();
			}
		}
	}

	private void tryToPickupItem(fishingItem currentEquiptment, RSGroundItem fishingItem) {
		if(DynamicClicking.clickRSGroundItem(fishingItem, "Take")){
			Timing.waitCondition(new Condition() {

				@Override
				public boolean active() {
					sleepSD();
					return currentEquiptment.carryingItem() || playerIsDoingNothing() || !fishingItem.isOnScreen();
				}
			}, randomSD(5000,10000, 7500, 1000));
		}
	}

	private void walkScreenPath(RSTile[] generateStraightScreenPath) {
		Walking.walkScreenPath(generateStraightScreenPath);		
	}

	private String getInteractingObjectName() {
		String result = "";
		RSPlayer player = Player.getRSPlayer();
		if(player != null){
			RSCharacter interactingChar = player.getInteractingCharacter();
			if(interactingChar != null){
				result = interactingChar.getName();
			}
		}
		return result;
	}

	private void discard() {
		sleepFishingReactionTime();
		if(currentProfile != null){
			if(currentProfile.useBoothBanker() || currentProfile.useDepositBox()){
				bank(false);
			}else{
				drop();
			}
		}
	}

	private void drop() {status = "CLEARING INVENT!";
	int tryAmount = randomSD(1, 25, tryMeanSD[0], tryMeanSD[1]);
	if(currentProfile != null){
		fishingEquiptment currentEquiptment = currentProfile.getEquiptment();
		if(currentEquiptment != null){
			int fishingEquiptmentId = currentEquiptment.getId();
			if(fishingEquiptmentId != -1){
				int[] dontDropIDS = currentProfile.getDontDropIDS();
				for(int i  = 0 ; i < tryAmount && getItemsExcept(currentEquiptment).length > 0; i++){
					if(checkGameText()){
						if(currentProfile.isDropMouseKeys()){
							dropAll(dontDropIDS);
						}else{
							Inventory.dropAllExcept(dontDropIDS);
						}
					}
					sleepSD();
				}
			}
		}
	}
	}

	private RSItem[] getItemsExcept(fishingEquiptment currentEquiptment) {
		RSItem[] result = Inventory.find(new Filter<RSItem>(){

			@Override
			public boolean accept(RSItem item) {
				boolean result = true;
				if(item != null){
					if(currentEquiptment != null){
						RSItemDefinition itemDef = item.getDefinition();
						if(itemDef != null){
							int itemID = itemDef.getID();
							if(itemID != -1){
								result = !currentEquiptment.idMatchesAnyEquiptment(itemID);
							}
						}
					}
				}
				return result;
			}

		});
		return result;
	}


	private final int NUMBER_INVENTORY_COLUMNS = 4;
	private final int NUMBER_INVENTORY_ROWS = 7;

	public  void dropAll(int[] dontDropIDS) {status = "SUPER SPEED!";

	if(Inventory.open()){
		int tryAmount = randomSD(1, 25, tryMeanSD[0], tryMeanSD[1]);
		Keyboard.sendPress(KeyEvent.CHAR_UNDEFINED, KeyEvent.VK_CONTROL);
		for(int i = 0 ; i < tryAmount ; i++){
			RSItem[] itemsToDrop = getItemsExcept(dontDropIDS);
			if(itemsToDrop != null && itemsToDrop.length > 7){
				itemsToDrop = to28(itemsToDrop);
				for(int column = 0 ; column < NUMBER_INVENTORY_COLUMNS ; column++){
					for(int row = 0 ; row < NUMBER_INVENTORY_ROWS; row++){
						int currentIndex = row * 4 + column;
						RSItem currentItem = itemsToDrop[currentIndex];
						if(currentItem != null){
							Rectangle rectangleAroundItem = currentItem.getArea();
							if(rectangleAroundItem != null){
								checkGameText();
								Point mousePosition = Mouse.getPos();
								if(mousePosition != null){
									if(!rectangleAroundItem.contains(mousePosition)){
										int moveX = rectangleAroundItem.x;
										int moveY = rectangleAroundItem.y;
										if(moveX != -1 && moveY != -1){
											CustomRet_0P<Point> pointToMoveTo = new CustomRet_0P<Point>() {
												@Override
												public Point ret() {
													Point result = new Point(moveX, moveY);
													return result;
												}
											};
											if(pointToMoveTo != null){
												int radius = Math.min(rectangleAroundItem.height, rectangleAroundItem.width);
												if(radius != -1){
													DynamicMouse.move(pointToMoveTo, radius);
												}
											}
										}
									}
									mousePosition = Mouse.getPos();
									if(mousePosition != null){
										if(rectangleAroundItem.contains(mousePosition)){
											TABS openTab = GameTab.getOpen();
											if(openTab != null){
												if(openTab.equals(TABS.INVENTORY)){
													Mouse.click(3);
													Timing.waitCondition(new Condition() {
														@Override
														public boolean active() {
															sleep(10);
															return ChooseOption.isOpen();
														}
													}, General.randomSD(500, 1000, 750, 100));
													final int yValue = getY();
													if(yValue != -1){
														Point mousePos = Mouse.getPos();
														if(mousePos != null){
															int xVal = mousePos.x;
															if(xVal != -1){
																Point pointToHopTo = new Point(xVal, yValue);
																if(pointToHopTo != null){
																	Mouse.hop(pointToHopTo);
																	Mouse.click(1);
																	Timing.waitCondition(new Condition() {

																		@Override
																		public boolean active() {
																			sleep(10);
																			return !ChooseOption.isOpen();
																		}
																	}, General.randomSD(500, 1000, 750, 100));
																}
															}
														}
													}
												}else{
													Inventory.open();
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		Keyboard.sendRelease(KeyEvent.CHAR_UNDEFINED, KeyEvent.VK_CONTROL);
	}
	}


	public  boolean checkGameText() {
		if(Game.getItemSelectionState() == 1){
			Mouse.click(General.random(2, 519), General.random(342, 472), 0);
		}
		return Game.getItemSelectionState() != 1;
	}

	private RSItem[] getItemsExcept(int[] dontDropIDS) {
		RSItem[] result = Inventory.find(new Filter<RSItem>(){

			@Override
			public boolean accept(RSItem item) {
				boolean result = true;
				if(item != null){
					RSItemDefinition itemDef = item.getDefinition();
					if(itemDef != null){
						int itemID = itemDef.getID();
						if(itemID != -1){
							for(int i : dontDropIDS){
								result = result && i != itemID;
							}
						}
					}
				}
				return result;
			}

		});
		return result;
	}

	public  RSItem[] to28(RSItem[] originalArray) {
		RSItem[] lengthenedArray = new RSItem[28];
		if(originalArray != null){
			for(int i = 0; i < originalArray.length; i++){
				RSItem current = originalArray[i];
				if(current != null){
					int index = current.getIndex();
					if(index != -1 && lengthenedArray.length > index){
						lengthenedArray[index] = current;
					}
				}
				lengthenedArray[originalArray[i].getIndex()] = originalArray[i];
			}
		}
		return lengthenedArray;
	}

	public  int getY() {
		int result = -1;
		final String[] actions = ChooseOption.getOptions();
		for (int i = 0; i < actions.length; i++) {
			String current = actions[i];
			if(current != null){
				current = current.toLowerCase();
				if(current != null){
					if(current.contains("drop")){
						Point optionsPosition = ChooseOption.getPosition();
						if(optionsPosition != null){
							int optionsPositionY = (int) optionsPosition.getY();
							if(optionsPositionY != -1){
								result = (int) optionsPositionY + 21 + 16 * i;
							}
						}
					}
				}
			}
		}
		return result;
	}

	private void bank(boolean missingEquiptment) {status = "Banking";

	RSPlayer player = Player.getRSPlayer();
	if(player != null){
		if(currentProfile != null){
			fishingArea currentArea = currentProfile.getArea();
			if(currentArea != null){
				RSArea bankingArea = currentArea.getBankArea();
				if(bankingArea != null){
					if(bankingArea.contains(player)){
						fishingEquiptment currentEquiptment = currentProfile.getEquiptment();
						if(currentEquiptment != null){ 
							int[] dontBankIDs = currentProfile.getDontBankIDS();
							if(fishingAtKaramja()){
								int[] temp = new int[dontBankIDs.length + 1];
								for(int i = 0 ; i < dontBankIDs.length ; i++){
									temp[i] = dontBankIDs[i];
								}
								temp[temp.length-1] = 995;
								dontBankIDs = temp;
								temp = null;
							}
							int tryAmount = randomSD(1, 25, tryMeanSD[0], tryMeanSD[1]);
							for(int i = 0 ; i < tryAmount && (getItemsExcept(dontBankIDs).length > 0 ||  !currentEquiptment.carryingItemAndBaits()); i++){
								if(openBank(missingEquiptment)){
									Banking.depositAllExcept(dontBankIDs);
								}
								if(getItemsExcept(dontBankIDs).length == 0){
									if(!currentEquiptment.carryingItemAndBaits()){
										withdrawItems();
									}
								}
								sleepSD();
							}
						}
					}else{
						walkToBank();
					}
				}else{
					println("You lost your equiptment and you are not near a bank to get it back.");
					stop = true;
				}
			}
		}
	}
	}

	private void sleepFishingReactionTime() {
		if(interactingWithSpot && !testing){
			long timeSpentWaiting = timeSpentFishing.getElapsed();
			averageTimeSpentFishing.addNumber(timeSpentWaiting);
			status = "Robot is AFK";
			setLoginBotState(false);
			anti.sleepReactionTime((int) timeSpentFishing.getElapsed(), wasInCombat);
			setLoginBotState(true);
			interactingWithSpot = false;
			wasInCombat = false;
		}
	}


	private boolean fishingAtKaramja() {
		boolean result = false;
		if(currentProfile != null){
			fishingArea currentArea = currentProfile.getArea();
			if(currentArea != null){
				String areaName = currentArea.getName();
				result = areaName.equalsIgnoreCase("northeastkaramja");
			}
		}
		return result;
	}

	private void withdrawItems() {
		if(Banking.isBankScreenOpen()){
			if(currentProfile != null){
				fishingEquiptment currentEquiptment = currentProfile.getEquiptment();
				if(currentEquiptment != null){
					fishingBait[] baits = currentEquiptment.getBaits();
					withdrawItem(currentEquiptment);
					if(baits != null){
						for(fishingBait bait : baits){
							withdrawItem(bait);
						}
					}
				}
			}
		}
	}

	private void withdrawItem(fishingItem item) {
		if(!item.carryingItem()){
			if(Banking.isBankScreenOpen()){
				int itemID = item.getId();
				if(itemID != -1){
					RSItem[] bankItems = Banking.find(itemID);
					if(bankItems != null){
						if(bankItems.length > 0){
							for(RSItem bankItem : bankItems){
								int amount = isBait(bankItem) ? this.BAIT_AMOUNT : 1;
								withdrawItem(bankItem, amount);
							}
						}else{
							println("You are out of " + item.getName() + ".  Stopping Script.");
							stop = true;
							return;
						}
					}
				}
			}
		}
	}

	private boolean isBait(RSItem item) {
		boolean result = false;
		RSItemDefinition itemDef = item.getDefinition();
		if(itemDef != null){
			int itemID = itemDef.getID();
			if(itemID != -1){
				if(currentProfile != null){
					fishingEquiptment currentEquiptment = currentProfile.getEquiptment();
					if(currentEquiptment != null){
						fishingBait[] currentBaits = currentEquiptment.getBaits();
						if(currentBaits != null){
							for(fishingBait currentBait : currentBaits){
								result = result || currentBait.idMatches(itemID);
							}
						}
					}
				}
			}
		}
		return result;
	}

	private boolean withdrawItem(RSItem bankItem, int amount) {
		Timing.waitCondition(new Condition() {

			@Override
			public boolean active() {
				return isBankItemsLoaded();
			}
		}, (long) randomSD(1000, 3000, baitMeanSD[0], baitMeanSD[1]));
		return Banking.withdrawItem(bankItem, amount);
	}

	public static boolean isBankItemsLoaded() {
		return getCurrentBankSpace() == Banking.getAll().length;
	}

	private static int getCurrentBankSpace() {
		RSInterface amount = Interfaces.get(12,3);
		if(amount != null) {
			String text = amount.getText();
			if(text != null) {
				try {
					if(text.matches("\\d+")){
						int parse = Integer.parseInt(text);
						if(parse > 0)
							return parse;
					}
				} catch(NumberFormatException e) {
					e.printStackTrace();
					return -1;
				}
			}
		}
		return -1;
	}

	private boolean openBank(boolean missingEquiptment) {
		if(!Banking.isPinScreenOpen() && !Banking.isPinMessageOpen() && !Banking.isBankScreenOpen() && !Banking.isDepositBoxOpen()){
			if(currentProfile != null){
				boolean bankBoothsPresent = areThereBankBooths();
				if(bankBoothsPresent && (currentProfile.useBoothBanker() || missingEquiptment)){
					Banking.openBank();
				}else if(currentProfile.useDepositBox() || fishingAtKaramja()){
					openDepositBoxBank();
				}else if((missingEquiptment || !currentProfile.useDepositBox()) && !bankBoothsPresent){
					openNPCBank();
				}
			}
		}
		return Banking.isBankScreenOpen() || Banking.isDepositBoxOpen();
	}

	private boolean areThereBankBooths() {
		RSObject[] bankBooths = Objects.find(15, new Filter<RSObject>(){

			@Override
			public boolean accept(RSObject obj) {
				boolean result = false;
				if(obj != null){
					RSObjectDefinition objDef = obj.getDefinition();
					if(objDef != null){
						String[] actions = objDef.getActions();
						String actionToSearchFor = "Bank";
						if(isStringInArrayOfStrings(actionToSearchFor, actions)){
							RSTile boothLocation = obj.getPosition();
							if(boothLocation != null){
								result = PathFinding.canReach(boothLocation, true);
							}
						}
					}
				}
				return result;
			}

		});
		return bankBooths.length > 0;
	}

	private boolean isStringInArrayOfStrings(String toSearchFor, String... actions) {
		boolean result = false;
		for(String action : actions){
			if(action.equalsIgnoreCase("Bank")){
				result = true;
			}
		}
		return result;
	}

	private boolean isStringContainedInArrayOfStrings(String toSearchFor, String... actions) {
		boolean result = false;
		for(String action : actions){
			if(action.contains(toSearchFor)){
				result = true;
			}
		}
		return result;
	}

	private void openDepositBoxBank() {
		RSObject[] depositBoxes = Objects.findNearest(10, "Bank deposit box");
		if(depositBoxes.length > 0){
			RSObject depositeBox = depositBoxes[0];
			if(!depositeBox.isOnScreen()){
				Camera.turnToTile(depositeBox);
			}
			if(depositeBox.isClickable()){
				DynamicClicking.clickRSObject(depositeBox, "Deposit");
			}
		}
	}

	private void openNPCBank() {
		RSNPC[] bankers = NPCs.findNearest(new Filter<RSNPC>(){

			@Override
			public boolean accept(RSNPC npc) {
				boolean result = false;
				if(npc != null){
					RSNPCDefinition npcDef = npc.getDefinition();
					if(npcDef != null){
						String[] actions = npcDef.getActions();
						String actionToSearchFor = "Bank";
						result = isStringInArrayOfStrings(actionToSearchFor, actions);
					}
				}
				return result;
			}

		});
		if(bankers != null){
			for (RSNPC banker : bankers) {
				if(banker.isValid()){
					if(banker.isOnScreen()){
						if(DynamicClicking.clickRSNPC(banker, "Bank ")){
							waitMonkBanker();
							if(Banking.isBankScreenOpen() || Banking.isPinMessageOpen() || Banking.isPinScreenOpen())break;
						}
					}else{
						Camera.turnToTile(banker);
					}
				}
			}
		}	
	}

	private void waitMonkBanker() {
		for(int i = 0 ; i <= 20 ; i++){
			if(Banking.isBankScreenOpen() || Banking.isPinScreenOpen())break;
			sleepSD();
		}

	}

	private void walkToBank() {status = "Walking to Bank";
	if(currentProfile != null){
		fishingArea area = currentProfile.getArea();
		if(area != null){
			RSArea bankArea = area.getBankArea();
			RSArea walkingArea = area.getWalkArea();
			if(bankArea != null && walkingArea != null){
				if(!fishingAtKaramja()){
					walkToArea(bankArea, walkingArea);
				}else{
					walkToKaramjaBankingArea();
				}
			}
		}
	}
	}

	private void aStarWalk(RSTile walkToTile, RSArea endingArea, Polygon... polygons) {
		anti.turnOnRun();
		if(anti.getWalkPref(walkToTile.distanceTo(Player.getRSPlayer())) == WalkingPreference.MINIMAP){
			PathFinding.aStarWalk(walkToTile, polygons);
			while(Player.isMoving() && !endingArea.contains(Player.getRSPlayer())){
				anti();
			}
		}else{
			Walking.walkScreenPath(Walking.generateStraightScreenPath(walkToTile));
		}
	}

	private void fish() {status = "Legit AFK Fishing";
	RSNPC targetSpot = getFishingSpot();
	if(Banking.close() && Banking.closePinMessage()){
		if(targetSpot != null){
			if(currentProfile != null){
				String option = currentProfile.getSpotOption(targetSpot);
				if(option != null){
					if(!option.isEmpty()){
						if(targetSpot.isOnScreen()){
							if(targetSpot.isClickable()){
								String interactingName = getInteractingObjectName();
								if(interactingName != null){
									if(!interactingName.equals("Fishing spot") || playerIsDoingNothing()){
										if(targetSpot.click(option)){
											Timing.waitCondition(new Condition() {
												@Override
												public boolean active() {
													sleep(250);
													boolean result = false;
													String interactingEntityName = getInteractingObjectName();
													if(interactingEntityName != null){
														if(interactingEntityName.equals("fishing spot")){
															if(!Player.isMoving()){
																if(!playerIsDoingNothing()){
																	result = true;
																}
															}
														}
													}
													return result;
												}
											}, randomSD(1500,2500, 2000, 250));
											anti.run((int) averageTimeSpentFishing.getCurrentAverage(), getPossibleSpots(false));
										}
									}
								}
							}
						}else{
							RSTile position = Player.getPosition();
							if(position != null){
								if(position.distanceTo(targetSpot)>= randomSD(1, 8, 4, 2)){
									if(walkPath(Walking.randomizePath(Walking.generateStraightPath(targetSpot), 1, 1))){
										while(!playerIsDoingNothing() && !targetSpot.isOnScreen()){
											Camera.turnToTile(randomizeTile(targetSpot, 2, 2));
											sleepSD();
										}
									}
								}else{
									Camera.turnToTile(randomizeTile(targetSpot, 2, 2));
								}
							}
						}
					}
				}
			}
		}else{
			nullSpotActions();
		}
	}
	}


	private RSTile randomizeTile(Positionable fishingSpot, int i, int j) {
		RSTile result = null;
		if(fishingSpot != null){
			RSTile position = fishingSpot.getPosition();
			if(position != null){
				int x = position.getX();
				int y = position.getY();
				if(x != -1 && y != -1){
					result = new RSTile(x+General.random(-i, i), y + General.random(-j, j));
				}
			}
		}
		return result;
	}

	private boolean walkPath(RSTile[] randomizePath) {
		anti.turnOnRun();
		return Walking.walkPath(randomizePath);
	}

	private void nullSpotActions() {
		anti();
	}

	private RSNPC getFishingSpot() {
		RSNPC result = null;
		RSNPC[] fishingSpots = getPossibleSpots(true);
		if(fishingSpots != null){
			if(fishingSpots.length > 0){
				anti.selectNextTarget(fishingSpots);
				result = (RSNPC) anti.getNextTarget();
				if(result == null){
					result = fishingSpots[randomSD(0, fishingSpots.length - 1, 0,2)];
				}
			}
		}
		return result;
	}

	/*private boolean stillValidSpot(RSNPC currentTarget) {
		if(currentTarget != null){
			systemMessage("Checking information");
			String output = "======================================================\n";
			output += "Get chat message: " + currentTarget.getChatMessage() + "\n";
			output += "Get Name: " + currentTarget.getName() + "\n";
			output += "To String: " + currentTarget.toString() + "\n";
			output += "Click height:" + currentTarget.click_height + "\n";
			output += "G: " + currentTarget.g + "\n";
			output += "Index: " + currentTarget.index + "\n";
			output += "L: " + currentTarget.L + "\n";
			output += "obj: " + currentTarget.obj + "\n";

			RSNPC[] npcs = NPCs.find(new Filter<RSNPC>(){

				@Override
				public boolean accept(RSNPC npc) {
					return npc.getIndex() == currentTarget.getIndex();
				}

			});

			output += "Found like NPCS " + (npcs.length > 0);

			output += "Actions: " + Arrays.toString(currentTarget.getActions()) + "\n";
			output += "Animable Position: " + currentTarget.getAnimablePosition() + "\n";
			output += "Animation: " + currentTarget.getAnimation() + "\n";
			output += "Height: " + currentTarget.getHeight() + "\n";
			output += "Child id: " + currentTarget.getChildID() + "\n";
			output += "Get Index: " + currentTarget.getIndex() + "\n";
			output += "Position: " + currentTarget.getPosition() + "\n";
			output += "Is Clickable: " + currentTarget.isClickable() + "\n";
			output += "Is On Screen: " + currentTarget.isOnScreen() + "\n";
			output += "======================================================\n";
			output += currentTarget.isValid() + " result";
			output += "======================================================\n";
			println(output);
		}else{
			println("can't check info spot is null");
		}
		return currentTarget != null && currentTarget.isValid();
	}*/

	private RSNPC[] getPossibleSpots(boolean getInteractingSpot) {
		RSNPC[] result = null;
		if(currentProfile != null){
			int[] spotIDS = currentProfile.getSpotIDS();
			fishingArea currentArea = currentProfile.getArea();
			if(currentArea != null){
				RSArea fishingArea = currentArea.getFishArea();
				if(fishingArea != null){
					RSPlayer player = Player.getRSPlayer();
					if(player != null){
						RSCharacter interactingChar = player.getInteractingCharacter();
						RSTile interactingCharTile = interactingChar == null ? null : interactingChar.getPosition();

						if(spotIDS != null){
							result =  NPCs.findNearest(new Filter<RSNPC>(){

								@Override
								public boolean accept(RSNPC npc) {
									boolean result = false;
									if(npc != null){
										if(npc.isValid()){
											int npcID = npc.getID();
											if(intInArray(npcID, spotIDS)){
												if(PathFinding.canReach(npc, true)){
													if(interactingCharTile == null || (interactingCharTile.distanceTo(npc) > 0 || getInteractingSpot)){
														result = closeToArea(npc, fishingArea, 1);
													}
												}
											}
										}
									}
									return result;
								}
								private boolean intInArray(int intToFind, int[] ints) {
									boolean result = false;
									if(ints != null){
										for(int i : ints){
											if(i == intToFind){
												result = true;
												break;
											}
										}
									}
									return result;
								}

							});
						}
					}
				}
			}
		}
		return result;
	}

	public boolean closeToArea(Positionable fishingSpot, RSArea area, int distance) {
		if(fishingSpot != null){
			RSTile[] fishingAreaTiles = area.getAllTiles();
			for(RSTile tile : fishingAreaTiles){
				if(tile.distanceTo(fishingSpot)<distance)return true;
			}
		}
		return false;
	}

	public  int getFishingLevel(){
		return Skills.getActualLevel(SKILLS.FISHING);
	}





	/*
	 * Painting section
	 */
	Font paintFont = new Font("arial", Font.BOLD, 14);
	boolean showPaint = true;
	@Override
	public void onPaint(Graphics g) {
		if(Login.getLoginState() == STATE.INGAME && paint != null){
			if(showPaint){
				drawPaintPicture(g);
				if(!stop){
					drawPercentBar(g);

					g.setColor(Color.BLACK);
					g.setFont(paintFont);

					drawExperience(g);
					drawRunTime(g);
					drawFishCaught(g);
					drawGeneralInfo(g);

				}
			}else{
				drawShowButton(g);
			}
		}
		drawMouse(g);
		paintLogo(g);
	}




	Image showButton;
	private void drawShowButton(Graphics g) {
		g.drawImage(showButton, 2, 315, null);
	}

	Image logoIcon;
	private void paintLogo(Graphics g){
		if(logoIcon != null){
			g.drawImage(logoIcon, 543, 4, null);
		}
	}


	double x = 0;
	double y = 0;
	Point mouse;
	Image mouseIcon;
	private void drawMouse(Graphics g) {
		mouse = Mouse.getPos();
		x = mouse.getX();
		y = mouse.getY();
		g.drawImage(mouseIcon, (int)x, (int)y, null);
	}

	public  String status = "Fishing";
	private String fishing = "No Fish Selected";
	private String location = "No Area Selected";
	private void drawGeneralInfo(Graphics g) {
		g.drawString("" + status, 245, 472);
		g.drawString("" + fishing, 245, 444);
		g.drawString("" + location, 245, 388);		
	}

	int levelperc = 0;
	int paintperc = 0;
	Color percentBar;
	private void drawPercentBar(Graphics g) {
		levelperc = Skills.getPercentToNextLevel(SKILLS.FISHING);
		paintperc = (int) Math.round(3.22*levelperc);
		if(paintperc > 0){
			g.setColor(percentBar);
			g.fillRect(192, 318, paintperc, 15);
			g.setColor(Color.CYAN);
			g.drawString(" "+levelperc+"% to "+(Skills.getCurrentLevel(SKILLS.FISHING)+1) + " | " + formatNumber(Skills.getXPToNextLevel(SKILLS.FISHING)) + " XP to go ", 295, 329);
		}
	}

	private Image paint;
	private void drawPaintPicture(Graphics g) {
		if(paint != null){
			g.drawImage(paint, 0, 313, null);
		}		
	}

	int gained = 0;
	private void drawExperience(Graphics g) {
		gained = whirlPool == null ? 0 :(int) whirlPool.tracker.getGained();
		if(gained > 0){
			g.drawString(gained+"  [ " + perHour(gained)+"/HR ]", 245, 360);
			g.drawString(" " + getTTL(gained), 430, 476);
		}else{
			g.drawString("No XP Gained", 245, 360);
			g.drawString(" Till EOC...", 430, 476);
		}
	}

	int caught = 0;
	private void drawFishCaught(Graphics g) {
		caught =  whirlPool == null ? 0 : whirlPool.catchTracker.getCaught();
		if(caught>0){
			g.drawString(" " + caught+"  [ " + perHour(caught)+"/HR ]", 245, 416);
		}else{
			g.drawString("No Fish Caught", 245, 416);	
		}
	}

	private void drawRunTime(Graphics g) {
		if(whirlPool != null){
			g.drawString(" " + Timing.msToString(whirlPool.timeRunning.getElapsed()), 430, 407 );
		}else{
			g.drawString(" " + Timing.msToString(0), 430, 407 );
		}
	}





	/*
	 * Utility methods for painting
	 */
	public static  Image getPaint(String urlAddress) {
		URL url = null;
		try{
			url = new URL(urlAddress);
		}catch(MalformedURLException e){

			e.printStackTrace();
		}
		if(url != null){
			ImageIcon result  = new ImageIcon(url);
			return result.getImage();
		}
		return null;
	}

	private int getTTLSecs(int gainedExp) {
		int seconds = (int) ((double) Skills.getXPToNextLevel(SKILLS.FISHING) / ((1000.0 / (double) runTime) * (double) gainedExp));
		if (seconds >= 60) {
			int minutes = seconds / 60;
			seconds -= (minutes * 60);
		}
		return seconds;
	}

	private int getTTLMins(int gainedExp) {
		int minutes = 0;
		int seconds = (int) ((double) Skills.getXPToNextLevel(SKILLS.FISHING) / ((1000.0 / (double) runTime) * (double) gainedExp));
		if (seconds >= 60) {
			minutes = seconds / 60;
			seconds -= (minutes * 60);
		}
		if (minutes >= 60) {
			int hours = minutes / 60;
			minutes -= (hours * 60);
		}
		return minutes;
	}

	private int getTTLHours(int gainedExp) {
		int hours = 0;
		int minutes = 0;
		int seconds = (int) ((double) Skills.getXPToNextLevel(SKILLS.FISHING)/ ((1000.0 / (double) runTime) * (double) gainedExp));
		if (seconds >= 60) {
			minutes = seconds / 60;
			seconds -= (minutes * 60);
		}
		if (minutes >= 60) {
			hours = minutes / 60;
			minutes -= (hours * 60);
		}
		return hours;
	}

	long runTime;
	private String getTTL(int gainedExp) {
		runTime = whirlPool.timeRunning.getElapsed();
		DecimalFormat nf = new DecimalFormat("00");
		return "" + nf.format(getTTLHours(gainedExp)) + ":"
		+ nf.format(getTTLMins(gainedExp)) + ":"
		+ nf.format(getTTLSecs(gainedExp));
	}





	/*
	 * Message Receivers
	 */
	@Override
	public void clanMessageReceived(String arg0, String arg1) {

	}

	@Override
	public void personalMessageReceived(String arg0, String arg1) {
	}

	@Override
	public void playerMessageReceived(String arg0, String arg1) {

	}

	@Override
	public void serverMessageReceived(String message) {
		if(message.contains("You catch")){
			if(whirlPool != null){
				whirlPool.catchTracker.addCaught();
			}		
		}
	}

	@Override
	public void tradeRequestReceived(String arg0) {
	}





	/*
	 * 
	 */
	public String perHour(int gained) {
		return formatNumber((int) ((gained) * 3600000D / whirlPool.timeRunning.getElapsed()));
	}

	public String formatNumber(int start) {
		DecimalFormat nf = new DecimalFormat("0.0");
		double i = start;
		if(i >= 1000000) {
			return nf.format((i / 1000000)) + "m";
		}
		if(i >=  1000) {
			return nf.format((i / 1000)) + "k";
		}
		return ""+start;
	}

	public int randomSD(int min, int max, double mean, double sd){
		if(mean < min || mean > max){
			double temp = mean;
			mean = sd;
			sd = temp;
		}
		return General.randomSD(min, max, (int) mean, (int) sd);
	}

	private double randomSDGenerator(final Random random, final double min, final double max,
			final double mean, final double sd) {
		double rand;

		do {
			rand = (int) (random.nextGaussian() * sd + mean);
		} while (rand < min || rand >= max);

		return rand;
	}

	private double[] generateCharacterProfile(final String username, double humanMean, double humanSD) {
		long seed = 0;

		for (int i = 0; i < username.length(); i++) {
			seed <<= 2;

			seed += username.charAt(i);
		}

		seed *= username.length();

		final Random random = new Random(seed);

		final double human_mean = humanMean;

		final double mean = randomSDGenerator(random, human_mean - (human_mean / 5), human_mean + (human_mean / 5), human_mean, human_mean / 25);

		final double human_sd = humanSD;

		final double sd = randomSDGenerator(random, human_sd - (human_sd / 10), human_sd + (human_sd / 10), human_sd, human_sd / 25);

		return new double[] { mean, sd, seed };
	}

	private void sleepSD(){
		sleep((long) randomSD(0, 30000, sleepMeanSD[0], sleepMeanSD[1]));
	}




	@Override
	public void onEnd() {
		Screenshots.take();
		println("Thank you for using ftwfisher, I appreciate it!");
	}




	/*
	 * Controlling paint
	 */
	Rectangle hide = new Rectangle(0, 313, 18, 20);
	Rectangle show = new Rectangle(2, 315, 59, 23);
	@Override
	public OVERRIDE_RETURN overrideKeyEvent(KeyEvent arg0) {
		return OVERRIDE_RETURN.PROCESS;
	}

	Point point;
	@Override
	public OVERRIDE_RETURN overrideMouseEvent(MouseEvent event) {
		if(event != null){
			point = event.getPoint();
			if((hide.contains(point) || show.contains(point)) && event.getClickCount() > 0){
				if(event.getID() == MouseEvent.MOUSE_CLICKED){
					point = event.getPoint();
					if(point != null){
						if((hide.contains(point) && showPaint) || (show.contains(point) && !showPaint)){
							showPaint = !showPaint;
						}
					}
				}
				return OVERRIDE_RETURN.DISMISS;
			}
		}
		return OVERRIDE_RETURN.PROCESS;
	}

	@Override
	public void duelRequestReceived(String arg0, String arg1) {

	}

	public static int getPrice(final int itemId) {
		try {
			URL url = new URL("https://api.rsbuddy.com/grandExchange?a=guidePrice&i=" + itemId);
			try (BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()))) {
				String line = reader.readLine();
				return line == null ? -1 : Integer.parseInt(line.substring(11, line.indexOf(',')));
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

		return -1;
	}

	/**
	 * Main method
	 */
	@Override
	public void run() {
		stop = false;
		setLoginBotState(false);
		String scriptname = getScriptName();
		isScriptPremium = !scriptname.contains("Lite");

		//Start GUI
		runGUI();
		setLoginBotState(true);

		//Change paint to the free version
		if(isScriptPremium){
			paint = getPaint("http://www.ftwscripting.com/ftwfisher/paint/premium.png");
		}else{
			paint = getPaint("http://www.ftwscripting.com/ftwfisher/paint/free.png");
		}

		logoIcon = getPaint("http://www.ftwscripting.com/ftwfisher/paint/icon.png");
		mouseIcon = getPaint("http://www.ftwscripting.com/ftwfisher/paint/mouse.png");
		showButton = getPaint("http://www.ftwscripting.com/ftwfisher/paint/show.gif");
		percentBar = new Color(204,102,0);

		//Wait for script to login
		status = "Waiting for Login";
		while(Login.getLoginState() != STATE.INGAME)sleep(100,250);
		//Generate user-specific values


		if(!npcAreHooked()){
			try {
				SwingUtilities.invokeAndWait(new Runnable() {

					@Override
					public void run() {
						JOptionPane.showMessageDialog(null, "Hey " + username + ",\n\nIt's NewBotterFTW's fishing script here! :)\n\nIt looks like the way we get the data on all the NPCs (Non-player characters) is broken.  TRiLeZ has to fix this.  The script will not start up any further.\n\n Thanks for your understanding,\nNewBotterFTW","NPCs aren't detected", JOptionPane.ERROR_MESSAGE);
					}
				});
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			setValues();
			//Main loop - enters if the values are set for the script
			if(valuesAreSet()){

				//reset timers for both sending data and 
				whirlPool.timeRunning.reset();
				whirlPool.tracker.reset();

				//starting the second thread

				//setting random settings
				General.useAntiBanCompliance(true);
				Mouse.setSpeed((int) randomSD(90,110, 100, 5));


				//Entering main loop
				while(!stop){
					sleep(100,200);
					anti();

					//Exit out of any chat interfaces encountered
					if(handleChat()){
						//if you are ready to fish, fish
						if(readyToFish()){
							loggedSpot = false;
							fish();
						}else

							//if you are ready to bank, bank
							if(readyToBankOrDiscard()){
								discard();
							}

						anti();

						//End of Loop, loops back if stop = false
					}
				}
			}else{


				println("Values aren't set, this means you did not complete the GUI properly.  If you have trouble with this, please contact me directly on Tribot - NewbotterFTW");
			}
			if(stop){
				logOut();
			}else{
				SwingUtilities.invokeLater(new Runnable() {

					@Override
					public void run() {
						JOptionPane.showMessageDialog(null, "The robot couldn\'t setup properly.  Please do not use the \"Re-run Script\" button at the top right.  If you would like to run the script again please use the \"Start Script\" button <3", "Robot Fail..", JOptionPane.ERROR_MESSAGE);
					}
				});
			}
		}
	}

	private boolean npcAreHooked() {
		boolean result = false;
		RSNPC[] npcs = NPCs.getAll();
		if(npcs != null && npcs.length > 0){
			for(RSNPC npc : npcs){
				String name = npc.getName();
				if(name != null && !name.isEmpty()){
					result = true;
					break;
				}
			}
		}else{
			result = true;
		}
		return result;
	}


	String wieldAction = "Wield";

	private void anti() {
		if(currentProfile != null){
			fishingEquiptment equiptment = currentProfile.getEquiptment();
			if(equiptment != null){
				if(!equiptment.carryingItem()){
					int equiptmentID = equiptment.getId();
					if(equiptmentID != -1){
						RSItem[] inventoryEquiptment = Inventory.find(equiptmentID);
						if(inventoryEquiptment != null){
							if(inventoryEquiptment.length > 0){
								for(RSItem inventoryItem : inventoryEquiptment){
									if(inventoryItem != null){
										RSItemDefinition itemDef = inventoryItem.getDefinition();
										if(itemDef != null){
											String[] actions = itemDef.getActions();
											if(actions != null){
												if(isStringInArrayOfStrings("Wield", actions)){
													if(inventoryItem.click(actions)){
														Timing.waitCondition(new Condition() {

															@Override
															public boolean active() {
																sleep(100,250);
																return equiptment.carryingItem();
															}
														}, randomSD(0, 2000, 1750, 250));
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		anti.run();
	}

	private void setValues() {
		RSPlayer player = Player.getRSPlayer();
		if(player != null){
			rsUsername = player.getName();
		}
		if(rsUsername.isEmpty()){
			rsUsername = username;
		}

		tryMeanSD = generateCharacterProfile(rsUsername, tryMeanSD[0], tryMeanSD[1]);
		sleepMeanSD = generateCharacterProfile(rsUsername, sleepMeanSD[0], sleepMeanSD[1]);
		baitMeanSD = generateCharacterProfile(rsUsername, baitMeanSD[0], baitMeanSD[1]);
		breakMeanSD = generateCharacterProfile(rsUsername, breakMeanSD[0], breakMeanSD[1]);

		BAIT_AMOUNT = ((int)(randomSD(1000, 25000, baitMeanSD[0], baitMeanSD[1])/1000))*1000;

		//sets world hopper to jump to free world if in free world or members if in members
		ftwWorldHopper.setFreeHopState();

		/*Creating objects from outside classes
		 * anti: Antiban class
		 * whirl: whirlpool and signature update thread from whirlPool object
		 * walkBack: Walks back to fishing spot if lost
		 * breaker: manages breaks and their times.
		 */

		anti = new ftwAnti();
		whirlPool = new ftwWhirlpoolDatabase(this);

		Thread whirlPoolThread = new Thread(new Runnable() {

			@Override
			public void run() {
				while(true){
					whirlPool.run();
					try {
						Thread.sleep(30000);
					} catch (InterruptedException e) {
					}
				}
			}
		});

		whirlPoolThread.start();

		if(currentProfile != null){
			fishingArea currentArea = currentProfile.getArea();
			if(currentArea != null){
				this.location = currentArea.getReadableName();
			}
			this.fishing = "";
			fishingLoot[] loots = currentProfile.getLoots();
			if(loots != null){
				for(int i = 0 ; i < loots.length ; i++){
					fishingLoot loot = loots[i];
					if(loot != null){
						this.fishing += loot.getReadableName();
						if(loots.length - i == 2){
							if(loots.length == 2){
								this.fishing += " and ";
							}else{
								this.fishing += ", and ";
							}
						}else if(loots.length - i > 2){
							this.fishing += ", ";
						}
					}
				}
			}
		}
	}
	private boolean valuesAreSet() {
		return currentProfile != null;
	}

	boolean testing = false;
	public void systemMessage(String message){
		if(testing){
			System.out.println(message);
		}
	}

}
