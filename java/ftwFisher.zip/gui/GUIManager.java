package scripts.fisher.gui;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import org.tribot.api.General;
import org.tribot.util.Util;

import scripts.fisher.classes.NonProgressiveProfile;
import scripts.fisher.classes.fishingArea;
import scripts.fisher.sideFiles.ftwImageLoader;
import scripts.fisher.sideFiles.ftwProfileLoader;

public class GUIManager{

	public static int guiStatus = 5;

	public static ftwProfileLoader loader = new ftwProfileLoader(General.getTRiBotUsername());

	public static NonProgressiveProfile profileServer = null;

	public void run() {
		try {
			int pastStatus = -1;
			while(guiStatus >= 0){
				if(guiStatus != pastStatus){
					switch(guiStatus){
					case 0:
						SwingUtilities.invokeLater(new Runnable() {
							public void run() {
								try {
									InstructionGUI frame = new InstructionGUI();
									frame.setVisible(true);
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						});
						break;
					case 1:
						SwingUtilities.invokeLater(new Runnable() {
							public void run() {
								try {
									MainProfileGUI frame = new MainProfileGUI();
									frame.setVisible(true);
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						});
						break;
					case 2:
						SwingUtilities.invokeLater(new Runnable() {
							public void run() {
								try {
									CreateProfileGUI frame = new CreateProfileGUI();
									frame.setVisible(true);
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						});
						break;
					case 3:
						SwingUtilities.invokeLater(new Runnable() {
							public void run() {
								try {
									MainProfileGUI frame = new MainProfileGUI();
									frame.setVisible(true);
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						});
						break;
					case 4:
						SwingUtilities.invokeLater(new Runnable() {
							public void run() {
								try{
									LoadingPictureGUI frame = new LoadingPictureGUI();
									frame.setVisible(true);
								}catch (Exception e){
									e.printStackTrace();
								}
							}
						});
						Runnable textUpdater = new Runnable() {

							@Override
							public void run() {
								try {
									Thread.sleep(100);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								long timeBetweenUpdates = 250;
								long currentTime = System.currentTimeMillis();
								while(!LoadingPictureGUI.loaded){
									if(System.currentTimeMillis() - currentTime > timeBetweenUpdates){
										currentTime = System.currentTimeMillis();
										LoadingPictureGUI.setRandomQuote();
									}
								}
							}
						};
						Thread GUIThread = new Thread(textUpdater);
						GUIThread.start();
						loadPresetFiles();
						fillAreaArray();
						LoadingPictureGUI.loaded = true;
						LoadingPictureGUI.startButton.setVisible(true);
						LoadingPictureGUI.quoteLabel.setVisible(false);
						break;
					case 5:
						if(!openedScriptBefore()){
							SwingUtilities.invokeAndWait(new Runnable() {

								@Override
								public void run() {
									JOptionPane.showMessageDialog(null, "Hi, I'm NewBotterFTW.  Thanks for choosing ftwfisher.  In a moment you will be prompted to allow some connections to my website.  Please do this by selecting \"Always Allow\"\nIt is the only way my script can work properly.  Thanks!  Love you!", "One Quick Thing Before We Start", JOptionPane.INFORMATION_MESSAGE);
								}
							});
						}

						String url = "http://www.ftwscripting.com";
						URL urlToAccess = new URL(url);
						try{
							InputStream stream = urlToAccess.openStream();
							stream.close();
							if(!openedScriptBefore()){
								SwingUtilities.invokeAndWait(new Runnable() {

									@Override
									public void run() {
										JOptionPane.showMessageDialog(null, "Great!  Now that you have allowed access to my website, my script will download all of the required files and then begin the tutorial.", "Here We Go!", JOptionPane.INFORMATION_MESSAGE);
									}
								});
							}
						}catch (Exception e){
							e.printStackTrace();
							SwingUtilities.invokeAndWait(new Runnable() {

								@Override
								public void run() {
									JOptionPane.showMessageDialog(null, "The script wasn\'t able to access my website, please add www.ftwscripting.com to your firewall which is located under the View menu on the top left.", "Whoops...", JOptionPane.ERROR_MESSAGE);
								}
							});
							GUIManager.guiStatus = -1;
						}

						break;
					}
					pastStatus = guiStatus;
					guiStatus = guiStatus == 5 ? 4 : guiStatus;
				}
				Thread.sleep(100);
			}
		} catch (Exception e){
			e.printStackTrace();
		}
	}

	public static boolean openedScriptBefore() {
		String filePath =  Util.getWorkingDirectory() + File.separator + "ftwfisher" + File.separator + "opened.txt";
		File file = new File(filePath);
		return file.exists();
	}

	private void fillAreaArray() {
		String filePath = Util.getWorkingDirectory() + File.separator + "ftwfisher" + File.separator + "presets" + File.separator + "area";
		File areaDir = new File(filePath);

		ArrayList<fishingArea> areas = new ArrayList<>();

		File[] filesInAreaDir = areaDir.listFiles();

		for(File fileInAreaDir : filesInAreaDir){
			if(fileInAreaDir.isFile()){
				areas.add(new fishingArea(fileInAreaDir));
			}
		}
		CreateProfileGUI.areas = areas.toArray(new fishingArea[0]);
	}

	private void loadPresetFiles() {
		String baseURL = "http://www.ftwscripting.com/ftwfisher/";
		try {
			URL urlToFileList = new URL(baseURL + "directories.php");
			InputStream stream = urlToFileList.openStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(stream, Charset.forName("UTF-8")));
			String rawText = GUITools.readAll(reader);
			String[] textFiles = rawText.split("<br />");
			formatURLS(baseURL, textFiles);
			downloadFiles(textFiles);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		loader.loadProfiles();

	}

	private void formatURLS(String baseURL, String[] textFiles) {
		for(int i = 0 ; i < textFiles.length ; i++){
			String current = textFiles[i];
			current = baseURL + current;
			textFiles[i] = current;
		}
		return;
	}

	private void downloadFiles(String... textFiles) throws IOException {

		ftwImageLoader loader = new ftwImageLoader("http://www.ftwscripting.com/ftwfisher", Util.getWorkingDirectory() + File.separator + "ftwfisher");
		String baseDir = Util.getWorkingDirectory() + File.separator + "ftwfisher" + File.separator;

		String sequenceToReplace = "http://www.ftwscripting.com/ftwfisher/";

		for(String current : textFiles){
			String pathWithoutBaseDirectory = current.replaceAll(sequenceToReplace, "");

			if(current.endsWith(".txt")){
				downloadTextFile(baseDir, current, pathWithoutBaseDirectory);
			}else{
				downloadImage(loader, pathWithoutBaseDirectory);
			}

		}
	}

	private void downloadImage(ftwImageLoader loader, String pathWithoutBaseDirectory) {
		int indexOfLastSlash = pathWithoutBaseDirectory.lastIndexOf("/");
		if(indexOfLastSlash != -1){

			String fileName = pathWithoutBaseDirectory.substring(indexOfLastSlash+1);
			pathWithoutBaseDirectory = pathWithoutBaseDirectory.replaceAll(fileName, "");

			String webURLLocal = pathWithoutBaseDirectory;
			String localDir = pathWithoutBaseDirectory.replace("/", File.separator);

			loader.setLocalDir(localDir);
			loader.setLocalURLDir(webURLLocal);
			loader.saveImageFromWeb(fileName);
		}
	}

	private void downloadTextFile(String baseDir, String current, String directoriesPastBaseString){
		try{
			URL currentURL = GUITools.convertToURLEscapingIllegalCharacters(current);
			InputStream currentStream = currentURL.openStream();
			BufferedReader currentReader = new BufferedReader(new InputStreamReader(currentStream, Charset.forName("UTF-8")));
			String filePathToWriteTo = baseDir + directoriesPastBaseString.replaceAll("//", File.separator);
			File fileToWriteTo = new File(filePathToWriteTo);
			writeFileFromWeb(currentReader, fileToWriteTo);
		}catch (Exception e){
			e.printStackTrace();
		}
	}


	private void writeFileFromWeb(BufferedReader currentReader, File fileToWriteTo) throws IOException {
		fileToWriteTo.mkdirs();
		if(fileToWriteTo.exists())fileToWriteTo.delete();
		fileToWriteTo.createNewFile();
		PrintWriter output = new PrintWriter(fileToWriteTo);
		while(currentReader.ready()){
			output.println(currentReader.readLine());
		}
		output.close();
	}
}
