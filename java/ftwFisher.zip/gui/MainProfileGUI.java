package scripts.fisher.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;

import org.tribot.util.Util;

import scripts.fisher.classes.NonProgressiveProfile;
import scripts.fisher.classes.NonProgressiveProfileInformation;
import scripts.fisher.sideFiles.ftwImageLoader;

public class MainProfileGUI extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final JLabel background = new JLabel();
	private final JButton useButton = new JButton("");
	private final JButton createButton = new JButton("");
	private final JButton deleteButton = new JButton("");
	private final JButton tutButton = new JButton("");
	private final JButton[] buttonsForPanel = {createButton, deleteButton, tutButton, useButton};

	private JList<NonProgressiveProfileInformation> profileList = new JList<NonProgressiveProfileInformation>();

	private final double profileManipulationButtonHeightPercent = 73;
	private final double profileManipulationButtonWidthDifFromMidPercent = 11;

	private final int profileListHeightPercent = 51;
	private final int profileListWidthPercent = 37;
	private final double profileListHeightLocationPercent = 40.75;
	private final double profileListWidthLocationPercent = 50;

	private final Font tableFont = new Font("Verdana", Font.BOLD, 15);
	private final Color tableFontColor = new Color(51, 142, 205);

	private final ftwImageLoader loader;


	/**
	 * Create the frame.
	 */
	public MainProfileGUI() {
		String baseURL = "http://www.ftwscripting.com/ftwfisher/gui";
		String baseDir = Util.getWorkingDirectory() + File.separator + "ftwfisher" + File.separator + "gui";
		loader = new ftwImageLoader(baseURL, baseDir);
		loader.setLocalDir("4-profilelist");
		loader.setLocalURLDir("4-profilelist");

		try {
			GUITools.setupGUINormals(this);
			GUITools.setframesizetoHD(66, this);

			GUITools.setBackground(loader.getImage("bg.jpg"), background, getContentPane());

			Image useButtonImage = loader.getImage("use.jpg");
			GUITools.setImageToButton(useButtonImage, 20, -1, useButton, getContentPane());
			GUITools.setComponentLocation(50, 84, useButton, getContentPane());

			Image createButtonImage = loader.getImage("create.jpg");
			GUITools.setImageToButton(createButtonImage, 15, -1, createButton, getContentPane());
			GUITools.setComponentLocation(50 - profileManipulationButtonWidthDifFromMidPercent, profileManipulationButtonHeightPercent, createButton, getContentPane());

			Image editButtonImage = loader.getImage("delete.jpg");
			GUITools.setImageToButton(editButtonImage, 15, -1, deleteButton, getContentPane());
			GUITools.setComponentLocation(50 + profileManipulationButtonWidthDifFromMidPercent, profileManipulationButtonHeightPercent, deleteButton, getContentPane());

			Image tutorialButtonImage = loader.getImage("tut.png");
			GUITools.setImageToButton(tutorialButtonImage, 10, -1, tutButton, getContentPane());
			GUITools.setComponentLocation(50, 93, tutButton, getContentPane());

			GUITools.addButtonsWithActionListener(buttonsForPanel, this, getContentPane());

			populateList();

			profileList.setFont(tableFont);
			profileList.setForeground(tableFontColor);
			profileList.setEnabled(true);
			JScrollPane scrollPane = new JScrollPane(profileList);
			GUITools.setComponentSizePercentContainer(profileListWidthPercent, profileListHeightPercent, scrollPane, getContentPane());
			GUITools.setComponentLocation(profileListWidthLocationPercent, profileListHeightLocationPercent, scrollPane, getContentPane());
			getContentPane().add(scrollPane);
		}catch (Exception e){
			e.printStackTrace();
		}

		getContentPane().add(background);
	}

	private void populateList() {
		NonProgressiveProfileInformation[] profiles = GUIManager.loader.getProfiles();

		DefaultListModel<NonProgressiveProfileInformation> model = new DefaultListModel<>();
		for(NonProgressiveProfileInformation profile : profiles){
			if(profile != null && profile.toString() != null && !profile.toString().isEmpty()){
				model.addElement(profile);
			}
		}

		profileList.setModel(model);

		boolean profilesListed = profileList.getModel().getSize() > 0;

		if(profilesListed){
			profileList.setSelectedIndex(0);
		}

		this.deleteButton.setEnabled(profilesListed);
		this.useButton.setEnabled(profilesListed);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if(source == tutButton){
			GUIManager.guiStatus = 0;
			this.dispose();
		}else if(source == createButton){
			GUIManager.guiStatus = 2;
			this.dispose();
		}else if(source == deleteButton){
			NonProgressiveProfileInformation toDelete = (NonProgressiveProfileInformation) profileList.getSelectedValue();
			GUIManager.loader.deleteProfile(toDelete);
			populateList();
		}else if(source == useButton){
			NonProgressiveProfileInformation selected = profileList.getSelectedValue();
			if(selected != null){
				NonProgressiveProfile profile = new NonProgressiveProfile(selected);
				GUIManager.profileServer = profile;
				GUIManager.guiStatus = -1;
				this.dispose();
			}
		}
	}

}
