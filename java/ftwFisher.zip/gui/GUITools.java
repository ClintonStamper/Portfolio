package scripts.fisher.gui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.net.URI;
import java.net.URL;
import java.net.URLDecoder;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import org.tribot.util.Util;

import scripts.fisher.sideFiles.ftwImageLoader;

public class GUITools {
	private static final String baseURL = "http://www.ftwscripting.com/ftwfisher/gui";
	private static final String baseDir = Util.getWorkingDirectory() + File.separator + "ftwfisher" + File.separator + "paint";
	private static final ftwImageLoader loader = new ftwImageLoader(baseURL, baseDir);

	/**
	 * Sets up the normal defaults for the frame.  This includes the close operation, content pane, resizableness, title, icon image, and what happens when the window closes.
	 * @param frameToSetDefaultsOn	This is the panel to set the defaults on.
	 * @throws IOException	This is thrown if any of the methods can't read a file.
	 */
	public final static void setupGUINormals(JFrame frameToSetDefaultsOn) throws IOException{
		frameToSetDefaultsOn.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		JPanel contentPane = new JPanel();
		contentPane.setLayout(null);
		frameToSetDefaultsOn.setContentPane(contentPane);

		frameToSetDefaultsOn.setResizable(false);
		frameToSetDefaultsOn.setTitle("ftwfisher by NewBotterFTW");
		loader.setLocalDir("icon");
		loader.setLocalURLDir("icon");
		frameToSetDefaultsOn.setIconImage(loader.getImage("icon.png"));

		frameToSetDefaultsOn.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent windowEvent){
				GUIManager.guiStatus = -1;
			}
		});
	}

	public final static void addButtonsWithActionListener(JButton[] components, ActionListener actionListener, Container contentPane){
		for(JButton comp : components){
			comp.addActionListener(actionListener);
			contentPane.add(comp, 0);
		}
	}

	/**
	 * Changes an image to the percent of either the jpanel width or height or a combination.
	 * @param imageToResize
	 * @param profileListWidthPercent
	 * @param contentPane
	 * @return
	 */
	public final static Image changeImageSizeByJpanelSize(Image imageToResize, int profileListWidthPercent, int profileListHeightPercent, Container contentPane) {
		if(imageToResize != null){
			restrictNumberWithinRange(0, 100, profileListWidthPercent);
			restrictNumberWithinRange(0, 100, profileListHeightPercent);

			Image result = imageToResize;

			int panelWidth = contentPane.getWidth();
			int panelHeight = contentPane.getHeight();

			double percentHeight = profileListHeightPercent/100.0;
			double percentWidth = profileListWidthPercent/100.0;

			double proposedWidth = panelWidth;
			double proposedHeight = panelHeight;

			if(percentWidth >= 0.01){
				proposedWidth =  panelWidth * percentWidth;
				restrictNumberWithinRange(0, panelWidth, proposedWidth);
			}

			if(percentHeight >= 0.01){
				proposedHeight = panelHeight * percentHeight;
				restrictNumberWithinRange(0, panelHeight, proposedHeight);
			}

			if(percentHeight < 0.01){
				proposedHeight = (proposedWidth/imageToResize.getWidth(null)) * result.getHeight(null);
			}

			if(percentWidth < 0.01){
				proposedWidth = (proposedHeight/imageToResize.getHeight(null)) * result.getWidth(null);
			}


			if(panelHeight < proposedHeight){
				proposedHeight = panelHeight;
				proposedWidth = (proposedHeight/imageToResize.getHeight(null)) * result.getWidth(null);
			}

			if(panelWidth < proposedWidth){
				proposedWidth = panelWidth;
				proposedHeight = (proposedWidth/imageToResize.getWidth(null)) * result.getHeight(null);
			}

			result = result.getScaledInstance((int)Math.round(proposedWidth), (int)Math.round(proposedHeight), Image.SCALE_SMOOTH);
			return result;
		}
		JOptionPane.showMessageDialog(null, "One of the images did not load from the server.\nPlease contact Newbotterftw and let him know of the issue", "Error", JOptionPane.ERROR_MESSAGE);
		return imageToResize;
	}

	/**
	 * 
	 * @param lowerLimit
	 * @param upperLimit
	 * @param proposedWidth
	 */
	private static void restrictNumberWithinRange(double lowerLimit, double upperLimit, double proposedWidth) {
		proposedWidth = proposedWidth > upperLimit ? upperLimit : proposedWidth;
		proposedWidth = proposedWidth < lowerLimit ? lowerLimit : proposedWidth;
	}

	/**
	 * 
	 * @param contentPanelToRef
	 * @param imageURL
	 * @param backgroundLabel
	 * @param contentPane
	 * @throws IOException
	 */
	public final static void setBackground(String imageURL, JLabel backgroundLabel, Container contentPane) throws IOException {
		Image imageToAdd = ImageIO.read(new File(imageURL));
		Image resizedImageToAdd = changeImageSizeByJpanelSize(imageToAdd, 100, 100, contentPane);
		backgroundLabel.setIcon(new ImageIcon(resizedImageToAdd));
		backgroundLabel.setBounds(0, 0, resizedImageToAdd.getWidth(null), resizedImageToAdd.getHeight(null));
	}

	public final static void setBackground(Image imageToAdd, JLabel backgroundLabel, Container contentPane) throws IOException {
		Image resizedImageToAdd = changeImageSizeByJpanelSize(imageToAdd, 100, 100, contentPane);
		backgroundLabel.setIcon(new ImageIcon(resizedImageToAdd));
		backgroundLabel.setBounds(0, 0, resizedImageToAdd.getWidth(null), resizedImageToAdd.getHeight(null));
	}


	/**
	 * 
	 * @param percentWidthHorizontalLocation
	 * @param percentHeightVeritcalLocation
	 * @param componentToManipulate
	 * @param contentPane
	 */
	public final static void setComponentLocation(double percentWidthHorizontalLocation, double percentHeightVeritcalLocation, JComponent componentToManipulate, Container contentPane) {
		double percentWidth = percentWidthHorizontalLocation/100.0;
		double percentHeight = percentHeightVeritcalLocation/100.0;

		int panelHeight = contentPane.getHeight();
		int panelWidth = contentPane.getWidth();

		double componentWidth = componentToManipulate.getBounds().getWidth();
		double componentHeight = componentToManipulate.getBounds().getHeight();

		double targetCenterHorizontal =  (panelWidth * percentWidth);
		double targetCenterVertical =  (panelHeight * percentHeight);

		double leftSideButton = targetCenterHorizontal - componentWidth/2.0;
		double topSideButton = targetCenterVertical - componentHeight/2.0;

		Rectangle currentBounds = componentToManipulate.getBounds();
		currentBounds.setBounds((int)Math.round(leftSideButton), (int)Math.round(topSideButton), componentToManipulate.getWidth(), componentToManipulate.getHeight());
		componentToManipulate.setBounds(currentBounds);
	}

	public final static void setComponentSizeToIcon(JLabel comp) {
		Icon icon = comp.getIcon();
		comp.setBounds(comp.getX(), comp.getY(), icon.getIconWidth(), icon.getIconHeight());
	}

	/**
	 * 
	 * @param percentWidth
	 * @param percentHeight
	 * @param componentToManipulate
	 * @param contentPane
	 */
	public final static void setComponentSizePercentContainer(double percentWidth, double percentHeight, JComponent componentToManipulate, Container contentPane){
		double percentWidthDouble = percentWidth/100.0;
		double percentHeightDouble = percentHeight/100.0;

		int panelHeight = contentPane.getHeight();
		int panelWidth = contentPane.getWidth();

		double targetWidth = (panelWidth * percentWidthDouble);
		double targetHeight = (panelHeight * percentHeightDouble);

		Rectangle currentBounds = contentPane.getBounds();
		currentBounds.setBounds((int)Math.round(currentBounds.getX()), (int)Math.round(currentBounds.getY()), (int)Math.round(targetWidth), (int)Math.round(targetHeight));

		componentToManipulate.setBounds(currentBounds);

	}

	/**
	 * 
	 * @param imageToUse
	 * @param percentOfContentPaneWidthInteger
	 * @param buttonToAddImageTo
	 * @param contentPane
	 */
	public final static void setImageToButton(Image imageToUse, int percentOfContentPaneWidthInteger, int percentOfContentPaneHeightInteger, JButton buttonToAddImageTo, Container contentPane) {
		Image resizedButton = changeImageSizeByJpanelSize(imageToUse, percentOfContentPaneWidthInteger, percentOfContentPaneHeightInteger, contentPane);
		buttonToAddImageTo.setIcon(new ImageIcon(resizedButton));
		Rectangle bounds = buttonToAddImageTo.getBounds();
		buttonToAddImageTo.setBounds((int)Math.round(bounds.getX()), (int)Math.round(bounds.getY()), (int)Math.round(resizedButton.getWidth(null)), (int)Math.round(resizedButton.getHeight(null)));
	}

	/**
	 * 
	 * @param percentOfScreenWidth
	 * @param frame
	 */
	public final static void setframesizetoHD(int percentOfScreenWidth, JFrame frame) {
		double percentTarget = percentOfScreenWidth/100.0;

		percentOfScreenWidth = percentOfScreenWidth > 100 ? 100 : percentOfScreenWidth;
		percentOfScreenWidth = percentOfScreenWidth < 0 ? 0 : percentOfScreenWidth;

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

		double screenWidth = screenSize.getWidth();
		double screenHeight = screenSize.getHeight();

		double suggestedWidth = (screenWidth * percentTarget);
		double suggestedHeight = ((suggestedWidth/1920.0)*1080);

		if(suggestedHeight > screenHeight){
			suggestedHeight = screenHeight;
			suggestedWidth =  ((suggestedHeight/1080.0)*1920);
		}

		frame.getContentPane().setPreferredSize(new Dimension((int)Math.round(suggestedWidth), (int)Math.round(suggestedHeight)));
		frame.pack();
		frame.setLocationRelativeTo(null);
	}
	
	
	public static String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}
	
	public static URL convertToURLEscapingIllegalCharacters(String string){
		try {
			String decodedURL = URLDecoder.decode(string, "UTF-8");
			URL url = new URL(decodedURL);
			URI uri = new URI(url.getProtocol(), url.getUserInfo(), url.getHost(), url.getPort(), url.getPath(), url.getQuery(), url.getRef()); 
			return uri.toURL(); 
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

}
