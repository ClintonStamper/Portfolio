package scripts.fisher.gui;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.tribot.util.Util;

import scripts.fisher.sideFiles.ftwImageLoader;

public class InstructionGUI extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 347147991208389688L;
	private final JButton continueButton = new JButton("");
	private final JLabel background = new JLabel();
  
	ArrayList<Image> backgroundImages = new ArrayList<>();
	ArrayList<Image> buttonImages = new ArrayList<>();
	
	private final ftwImageLoader loader;

	String[][] backgroundStrings = {{"1-welcome","bg.jpg"}
			, {"2-features", "bg.jpg"}
			, {"3-howitworks" + File.separator + "step1" , "bg.jpg"}
			, {"3-howitworks" + File.separator + "step2" , "bg.jpg"}
			, {"3-howitworks" + File.separator + "step3" , "bg.jpg"}
			, {"3-howitworks" + File.separator + "step4" , "bg.jpg"}};
	String[][] buttonStrings = {{"1-welcome" , "btn.jpg"}
			, {"2-features" , "btn.jpg"}
			, {"3-howitworks" + File.separator + "buttons" , "next.jpg"}
			, {"3-howitworks" + File.separator + "buttons" , "next.jpg"}
			, {"3-howitworks" + File.separator + "buttons" , "last.jpg"}
			, {"3-howitworks" + File.separator + "buttons" , "start.jpg"}};

	int currentPosition = -1;

	/**
	 * Create the frame.
	 */
	public InstructionGUI() {
		
		String baseURL = "http://www.ftwscripting.com/ftwfisher/gui";
		String baseDir = Util.getWorkingDirectory() + File.separator + "ftwfisher" + File.separator + "gui";
		loader = new ftwImageLoader(baseURL, baseDir);
		
		try {
			GUITools.setupGUINormals(this);
			fillImageLists();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		getContentPane().add(continueButton);
		getContentPane().add(background);
		GUITools.setframesizetoHD(66, this);

		try {
			setTitle("ftwfisher by NewBotterFTW");
			loader.setLocalDir("icon");
			loader.setLocalURLDir("icon");
			setIconImage(loader.getImage("icon.png"));
			presentNextImageButtonPair();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		GUITools.setComponentLocation(50, 90, continueButton, getContentPane());
		
		continueButton.addActionListener(this);
	}

	private boolean presentNextImageButtonPair() throws IOException {
		currentPosition++;
		if(currentPosition >= backgroundImages.size() || currentPosition >= buttonImages.size()){
			return false;
		}else{
			int nextImageIndex = currentPosition;

			Image backgroundImage = backgroundImages.get(nextImageIndex);
			GUITools.setBackground(backgroundImage, this.background, getContentPane());

			Image buttonImage = buttonImages.get(nextImageIndex);
			GUITools.setImageToButton(buttonImage, 20, -1, continueButton, getContentPane());
			
			return true;
		}
	}

	private void fillImageLists() throws IOException {
		for(int i = 0 ; i < backgroundStrings.length && i < buttonStrings.length ; i++){
			loader.setLocalURLDir(backgroundStrings[i][0]);
			loader.setLocalDir(backgroundStrings[i][0]);
			Image tempBackgroundImage = loader.getImage(backgroundStrings[i][1]);
			backgroundImages.add(tempBackgroundImage);
			
			loader.setLocalURLDir(buttonStrings[i][0]);
			loader.setLocalDir(buttonStrings[i][0]);
			Image tempButtonImage = loader.getImage(buttonStrings[i][1]);
			buttonImages.add(tempButtonImage);
		}

	}

	@Override
	public void actionPerformed(ActionEvent event) {
		Object source = event.getSource();
		if(source == this.continueButton){
			try {
				if(!presentNextImageButtonPair()){
					String filePath =  Util.getWorkingDirectory() + File.separator + "ftwfisher" + File.separator + "opened.txt";
					File file = new File(filePath);
					file.mkdirs();
					file.createNewFile();
					GUIManager.guiStatus = 1;
					this.dispose();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public ftwImageLoader getLoader() {
		return loader;
	}

}
