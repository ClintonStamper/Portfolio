package scripts.fisher.gui;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.tribot.api.General;
import org.tribot.util.Util;

import scripts.fisher.sideFiles.ftwImageLoader;

public class LoadingPictureGUI extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1653005930101229892L;
	private final JLabel loadingLabel = new JLabel();
	private final JLabel background = new JLabel();

	public static final JLabel quoteLabel = new JLabel("YOU'RE A LEGEND");
	private static final String[] quotes = {"Fishing for B0ATY", "Wooxing the Win", "Playing With The KBD", "Praying to Zezima", "Teabagging MMORPG's Ely", "Arm Thinging With Faux", "Banning Some JMods", "Skilling With Worthy", "Hacking Ragex", "Becoming Your Bae", "Sexting Knightenator", "Dumping EmilyIsPro", "Skyping with Mom", "Humanizing The Script", "Trumping The US", "Creating Raid Rewards", "Ordering a Hooker", "Prepping for 24 Hours", "Chatting With TRiLeZ", "Streaming On Twitch", "Deploying Monkey Workers", "Starting Ironman Account", "Stealing yo girl", "Stealing yo man", "Studying your account", "LOL at your levels", "Training for Deadmanmode", "Hiring A Robot", "Studying RSWiki"};
	private final Font quoteFont = new Font("Verdana", Font.ITALIC + Font.BOLD, 12);

	public final static JButton startButton = new JButton();
	private final JButton[] startButtons = {startButton};
	private final int distanceFromLeftstartButton = 50;
	private final int distanceFromTopstartButton = 87;
	private final int sizePercentWidthstartButton = 50;

	public static int periods = -1;
	public static boolean loaded = false;

	private final ftwImageLoader loader;


	public static void main(String[] args) {
		final LoadingPictureGUI frame = new LoadingPictureGUI();
		frame.setVisible(true);
	}

	/**
	 * Create the frame.
	 */
	public LoadingPictureGUI() {
		String baseURL = "http://www.ftwscripting.com/ftwfisher/gui";
		String baseDir = Util.getWorkingDirectory() + File.separator + "ftwfisher" + File.separator + "gui";
		setAlwaysOnTop(true);
		loader = new ftwImageLoader(baseURL, baseDir);
		loader.setLocalDir("loading");
		loader.setLocalURLDir("loading");
		this.setBounds(0, 0, 300, 400);
		try {
			GUITools.setupGUINormals(this);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.setLocationRelativeTo(null);
		this.setType(Type.UTILITY);
		Container contentPane = getContentPane();
		contentPane.setBounds(0, 0, 300, 400);

		URL url = null;
		try {
			url = new URL("http://ftwscripting.com/ftwfisher/gui/loading/fishing.gif");
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Icon image = new ImageIcon(url);
		loadingLabel.setIcon(image);
		loadingLabel.setBounds(60, 25, 180, 300);
		contentPane.add(loadingLabel);

		quoteLabel.setFont(quoteFont);
		quoteLabel.setHorizontalAlignment(JLabel.CENTER);
		quoteLabel.setVerticalAlignment(JLabel.CENTER);
		quoteLabel.setForeground(Color.BLACK);
		quoteLabel.setBounds(50, 300, 200, 100);
		contentPane.add(quoteLabel);

		Icon bgImage = new ImageIcon(loader.getImage("bg.jpg"));
		background.setIcon(bgImage);
		background.setBounds(0, 0, 300, 400);

		Image buttonImage = loader.getImage("start.jpg");
		GUITools.setImageToButton(buttonImage, sizePercentWidthstartButton, -1, startButton, contentPane);
		GUITools.setComponentLocation(distanceFromLeftstartButton, distanceFromTopstartButton, startButton, contentPane);
		GUITools.addButtonsWithActionListener(startButtons, this, contentPane);
		startButton.setVisible(false);
		contentPane.add(background);
		setVisible(true);
	}

	public static void setRandomQuote() {
		String current = LoadingPictureGUI.quoteLabel.getText();
		int currentPeriods = countOccurrances(current, '.');
		if(currentPeriods >= periods){
			int index = General.random(0, quotes.length - 1);
			current = quotes[index];
			periods = General.random(3, 6);
		}else{
			current += ".";
		}
		quoteLabel.setText(current);
	}

	public static int countOccurrances(String stringToLookAt, char... charactersToFind){
		int result = 0;
		for(char characterToFind : charactersToFind){
			for(int i = 0 ; i < stringToLookAt.length() ; i++){
				result = stringToLookAt.charAt(i) == characterToFind ? result + 1 : result;
			}
		}
		return result;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if(source == LoadingPictureGUI.startButton){
			if(GUIManager.openedScriptBefore()){
				GUIManager.guiStatus = 1;
			}else{
				GUIManager.guiStatus = 0;
			}
			this.dispose();
		}
	}

}
