package scripts.fisher.gui;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.tribot.util.Util;

import scripts.fisher.classes.NonProgressiveProfileInformation;
import scripts.fisher.classes.fishingArea;
import scripts.fisher.classes.fishingEquiptment;
import scripts.fisher.classes.fishingLoot;
import scripts.fisher.sideFiles.ftwImageLoader;

public class CreateProfileGUI extends JFrame implements ActionListener{

	private static final long serialVersionUID = -3858611201911282549L;


	//Non=Specific Variables
	private final JLabel background = new JLabel();
	
	private final Color noNameBackgroundColor = new Color(234, 56, 56);
	private final Color noNameForegroundColor = new Color(239, 239, 239);

	private final int distanceFromTopSelectButtons = 78;
	private final int distanceFromLeftSelectButtons = 50;
	private final int sizePercentSelectButtons = 25;

	private final JLabel currentChoice = new JLabel();
	private final int distanceFromTopChoiceImage = 36;
	private final int distanceFromLeftChoiceImage = 50;
	private final int sizePercentChoiceImage = 9;
	private int currentChoiceIndex = 0;
	private String choiceStringBase = "";
	private String[] choiceNames = {};

	private final JButton leftArrowButton = new JButton();
	private final JButton rightArrowButton = new JButton();
	private final JButton[] arrowButtons = {leftArrowButton, rightArrowButton};
	private final int distanceFromCenterArrowButtons = 15;
	private final int distanceFromTopArrowButtons = 36;
	private final int buttonArrowsWidthPercent = 5;
	
	private final JButton backButton = new JButton();
	private final JButton[] backButtonArray = {backButton};
	private final int distanceFromLeftBackButton = 50;
	private final int distanceFromTopBackButton = 92;
	private final int buttonBackWidthPercent = 17;


	//Specific Screen Variables
	private final JButton normalButton = new JButton();
	private final JButton advanceButton = new JButton();
	private final JButton[] modeSelectionButtons = {normalButton, advanceButton};
	private final int distanceFromCenterModeButtons = 28;
	private final int distanceFromTopModeButtons = 70;
	private final int buttonModeWidthPercent = 24;

	private final JButton selectSpotButton = new JButton();
	private final JButton[] selectSpotButtons = {selectSpotButton};
	private final String spotStringBase = "5-createprofile" + File.separator + "3-spot" + File.separator + "spots" + File.separator + "%.png";
	private fishingArea selectedArea = null;
	public static fishingArea[] areas = {};


	private final JButton selectEquiptmentButton = new JButton();
	private final JButton[] selectEquiptmentButtons = {selectEquiptmentButton};
	private final String equiptmentStringBase = "5-createprofile" + File.separator + "4-equiptment" + File.separator + "equipt" + File.separator + "%.png";

	public fishingEquiptment[] equiptments = {};


	private final JButton selectFishButton = new JButton();
	private final JButton[] selectFishButtons = {selectFishButton};
	private final String fishStringBase = "5-createprofile" + File.separator + "5-fish" + File.separator + "fish" + File.separator + "%.png";
	public fishingLoot[] loots = {};

	private final JButton saveProfileButton = new JButton();
	private final int distanceFromLeftSaveButton = 50;
	private final int distanceFromTopSaveButton = 90;
	private final int buttonSaveWidthPercent = sizePercentSelectButtons;

	private final JButton extraProfileButton = new JButton();
	private final JButton timeProfileButton = new JButton();
	private final int distanceFromCenterCustomButtons = 28;
	private final int distanceFromTopCustomButtons = 70;
	private final int buttonCustomWidthPercent = 20;

	private final JButton setNameButton = new JButton();
	private final JButton[] setNameButtons = {setNameButton};
	private final JTextField nameTextField = new JTextField();
	private final int distanceFromLeftNameButton = 50;
	private final int distanceFromTopNameButton = distanceFromTopSelectButtons;
	private final int buttonNameWidthPercent = sizePercentSelectButtons;
	private final int distanceFromLeftNameField = 50;
	private final int distanceFromTopNameField = 55;
	private final int sizePercentWidthNameField = 40;
	private final int sizePercentHeightNameField = 7;

	private final JButton selectBankBoothButton = new JButton();
	private final JButton selectDepositBoxButton = new JButton();
	private final JButton selectNormalDropButton = new JButton();
	private final JButton selectMouseKeyDropButton = new JButton();
	private final JButton[] bankSelectionButtons = {selectBankBoothButton, selectDepositBoxButton, selectNormalDropButton, selectMouseKeyDropButton};
	private final int bankSelectionButtonHeightPercent = 75;
	private final int bankSelectionInnerButtonSpreadPercent = 13;
	private final int bankSelectionOuterButtonSpreadPercent = 38;
	private final int bankSelectionSizePercentWidth = 15;

	private final Font jTextFieldFontNameField = new Font("Verdana", Font.BOLD, 20);
	private final Color jTextFieldFontColorNameField = new Color(51, 142, 205);

	private final JButton[] lastPageButtons = {saveProfileButton, extraProfileButton, timeProfileButton};

	private final ftwImageLoader loader;

	private boolean normal = true;
	private String selectedLootName = "";
	private String selectedEquiptmentName = "";
	private String selectedAreaName = "";
	private int bankMethod = 0;
	private String name = "";

	/**
	 * Create the frame.
	 */
	public CreateProfileGUI() {
		String baseURL = "http://www.ftwscripting.com/ftwfisher/gui/";
		String baseDir = Util.getWorkingDirectory() + File.separator + "ftwfisher" + File.separator + "gui";
		loader = new ftwImageLoader(baseURL, baseDir);
		try {
			GUITools.setupGUINormals(this);
			GUITools.setframesizetoHD(66, this);
			setUpArrowButtons();
			setUpBackButton();
			getContentPane().add(currentChoice);
			getContentPane().add(background);
			setUpModeSelectionScreen();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private void clearPanels() {
		getContentPane().removeAll();
	}

	private void setUpModeSelectionScreen() throws IOException {
		loader.setLocalDir("5-createprofile" + File.separator + "2-mode");
		loader.setLocalURLDir("5-createprofile/2-mode");

		Container contentPane = getContentPane();
		GUITools.setBackground(loader.getImage("bg.jpg"), background, contentPane);

		Image normalButtonImage = loader.getImage("normal.jpg");
		GUITools.setImageToButton(normalButtonImage, buttonModeWidthPercent, -1, normalButton, contentPane);
		GUITools.setComponentLocation(50 - distanceFromCenterModeButtons, distanceFromTopModeButtons, normalButton, contentPane);

		Image advanceButtonImage = loader.getImage("advance.jpg");
		GUITools.setImageToButton(advanceButtonImage, buttonModeWidthPercent, -1, advanceButton, contentPane);
		GUITools.setComponentLocation(50 + distanceFromCenterModeButtons, distanceFromTopModeButtons, advanceButton, contentPane);
		advanceButton.setEnabled(false);

		GUITools.addButtonsWithActionListener(backButtonArray, this, contentPane);
		GUITools.addButtonsWithActionListener(modeSelectionButtons, this, getContentPane());
	}

	private void setUpSpotSelectionScreen() throws IOException {
		loader.setLocalDir("5-createprofile" + File.separator + "3-spot");
		loader.setLocalURLDir("5-createprofile/3-spot");

		Container contentPane = getContentPane();

		GUITools.setBackground(loader.getImage("bg.jpg"), background, contentPane);
		contentPane.add(currentChoice);
		contentPane.add(background);

		GUITools.addButtonsWithActionListener(arrowButtons, this, contentPane);

		Image selectSpotButtonImage = loader.getImage("select.jpg");
		GUITools.setImageToButton(selectSpotButtonImage, sizePercentSelectButtons, -1, selectSpotButton, contentPane);
		GUITools.setComponentLocation(distanceFromLeftSelectButtons, distanceFromTopSelectButtons, selectSpotButton, contentPane);

		currentChoiceIndex = 0;
		choiceNames = getNames(areas);
		choiceStringBase = spotStringBase;
		displayNextChoice(0);
		GUITools.addButtonsWithActionListener(backButtonArray, this, contentPane);
		GUITools.addButtonsWithActionListener(selectSpotButtons, this, contentPane);
	}

	private String[] getNames(fishingArea[] areas) {
		ArrayList<String> names = new ArrayList<>();
		for(fishingArea area : areas){
			names.add(area.getName());
		}
		return names.toArray(new String[] {});
	}

	private void setUpEquiptmentSelectionScreen() throws IOException {
		loader.setLocalDir("5-createprofile" + File.separator + "4-equiptment");
		loader.setLocalURLDir("5-createprofile/4-equiptment");

		Container contentPane = getContentPane();

		GUITools.setBackground(loader.getImage("bg.jpg"), background, contentPane);
		contentPane.add(currentChoice);
		contentPane.add(background);
		GUITools.addButtonsWithActionListener(arrowButtons, this, contentPane);

		Image selectEquiptmentButtonImage = loader.getImage("select.jpg");
		GUITools.setImageToButton(selectEquiptmentButtonImage, sizePercentSelectButtons, -1, selectEquiptmentButton, contentPane);
		GUITools.setComponentLocation(distanceFromLeftSelectButtons, distanceFromTopSelectButtons, selectEquiptmentButton, contentPane);

		currentChoiceIndex = 0;
		choiceNames = getNames(equiptments);
		choiceStringBase = equiptmentStringBase;
		displayNextChoice(0);
		GUITools.addButtonsWithActionListener(backButtonArray, this, contentPane);
		GUITools.addButtonsWithActionListener(selectEquiptmentButtons, this, contentPane);
	}

	private String[] getNames(fishingEquiptment[] equiptments) {
		ArrayList<String> names = new ArrayList<>();
		for(fishingEquiptment equiptment : equiptments){
			names.add(equiptment.getName());
		}
		return names.toArray(new String[] {});
	}

	private void setUpFishSelectionScreen() throws IOException {
		loader.setLocalDir("5-createprofile" + File.separator + "5-fish");
		loader.setLocalURLDir("5-createprofile/5-fish");

		Container contentPane = getContentPane();

		GUITools.setBackground(loader.getImage("bg.jpg"), background, contentPane);
		contentPane.add(currentChoice);
		contentPane.add(background);
		GUITools.addButtonsWithActionListener(arrowButtons, this, contentPane);

		Image selectFishButtonImage = loader.getImage("select.jpg");
		GUITools.setImageToButton(selectFishButtonImage, sizePercentSelectButtons, -1, selectFishButton, contentPane);
		GUITools.setComponentLocation(distanceFromLeftSelectButtons, distanceFromTopSelectButtons, selectFishButton, contentPane);

		currentChoiceIndex = 0;
		choiceNames = getNames(loots);
		choiceStringBase = fishStringBase;
		displayNextChoice(0);
		GUITools.addButtonsWithActionListener(backButtonArray, this, contentPane);
		GUITools.addButtonsWithActionListener(selectFishButtons, this, contentPane);
	}

	private String[] getNames(fishingLoot[] loots) {
		ArrayList<String> names = new ArrayList<>();
		for(fishingLoot loot : loots){
			names.add(loot.getName());
		}
		return names.toArray(new String[] {});
	}

	private void setUpFinalExtrasScreen() throws IOException {
		loader.setLocalDir("5-createprofile" + File.separator + "6-custom");
		loader.setLocalURLDir("5-createprofile/6-custom");

		Container contentPane = getContentPane();

		GUITools.setBackground(loader.getImage("bg.jpg"), background, contentPane);

		Image saveProfileButtonImage = loader.getImage("save.jpg");
		GUITools.setImageToButton(saveProfileButtonImage, buttonSaveWidthPercent, -1, saveProfileButton, contentPane);
		GUITools.setComponentLocation(distanceFromLeftSaveButton, distanceFromTopSaveButton, saveProfileButton, contentPane);

		Image timeProfileButtonImage = loader.getImage("time.jpg");
		GUITools.setImageToButton(timeProfileButtonImage, buttonCustomWidthPercent, -1, timeProfileButton, contentPane);
		GUITools.setComponentLocation(50 + distanceFromCenterCustomButtons, distanceFromTopCustomButtons, timeProfileButton, contentPane);

		Image extraProfileButtonImage = loader.getImage("extra.jpg");
		GUITools.setImageToButton(extraProfileButtonImage, buttonCustomWidthPercent, -1, extraProfileButton, contentPane);
		GUITools.setComponentLocation(50-distanceFromCenterCustomButtons, distanceFromTopCustomButtons, extraProfileButton, contentPane);

		GUITools.addButtonsWithActionListener(backButtonArray, this, contentPane);
		GUITools.addButtonsWithActionListener(lastPageButtons, this, contentPane);
		contentPane.add(background);
	}

	private void setUpSaveNameScreen() throws IOException {
		loader.setLocalDir("5-createprofile" + File.separator + "1-name");
		loader.setLocalURLDir("5-createprofile/1-name");

		Container contentPane = getContentPane();

		GUITools.setBackground(loader.getImage("bg.jpg"), background, contentPane);

		Image setNameButtonImage = loader.getImage("set.jpg");
		GUITools.setImageToButton(setNameButtonImage, buttonNameWidthPercent, -1, setNameButton, contentPane);
		GUITools.setComponentLocation(distanceFromLeftNameButton, distanceFromTopNameButton, setNameButton, contentPane);

		GUITools.addButtonsWithActionListener(backButtonArray, this, contentPane);
		GUITools.addButtonsWithActionListener(setNameButtons, this, contentPane);

		GUITools.setComponentSizePercentContainer(sizePercentWidthNameField, sizePercentHeightNameField, nameTextField, contentPane);
		GUITools.setComponentLocation(distanceFromLeftNameField, distanceFromTopNameField, nameTextField, contentPane);
		nameTextField.setHorizontalAlignment(JTextField.CENTER);
		nameTextField.setForeground(jTextFieldFontColorNameField);
		nameTextField.setFont(jTextFieldFontNameField);

		contentPane.add(nameTextField);
		nameTextField.requestFocus();
		contentPane.add(background);
	}

	private void setupBankChoiceScreen() throws IOException {
		loader.setLocalDir("5-createprofile" + File.separator + "7-bank");
		loader.setLocalURLDir("5-createprofile/7-bank");

		Container contentPane = getContentPane();

		GUITools.setBackground(loader.getImage("bg.jpg"), background, contentPane);

		Image selectBankBoothButtonImage = loader.getImage("bankbooth.jpg");
		GUITools.setImageToButton(selectBankBoothButtonImage, bankSelectionSizePercentWidth, -1, selectBankBoothButton, contentPane);
		GUITools.setComponentLocation(50-bankSelectionOuterButtonSpreadPercent, bankSelectionButtonHeightPercent, selectBankBoothButton, contentPane);
		selectBankBoothButton.setEnabled(selectedArea.isThereBankBooth());

		Image selectDepositBoxButtonImage = loader.getImage("db.jpg");
		GUITools.setImageToButton(selectDepositBoxButtonImage, bankSelectionSizePercentWidth, -1, selectDepositBoxButton, contentPane);
		GUITools.setComponentLocation(50-bankSelectionInnerButtonSpreadPercent, bankSelectionButtonHeightPercent, selectDepositBoxButton, contentPane);
		selectDepositBoxButton.setEnabled(selectedArea.isThereDepositBox());

		Image selectNormalDropButtonImage = loader.getImage("normal.jpg");
		GUITools.setImageToButton(selectNormalDropButtonImage, bankSelectionSizePercentWidth, -1, selectNormalDropButton, contentPane);
		GUITools.setComponentLocation(50+bankSelectionInnerButtonSpreadPercent, bankSelectionButtonHeightPercent, selectNormalDropButton, contentPane);

		Image selectMouseKeyButtonImage = loader.getImage("mk.jpg");
		GUITools.setImageToButton(selectMouseKeyButtonImage, bankSelectionSizePercentWidth, -1, selectMouseKeyDropButton, contentPane);
		GUITools.setComponentLocation(50+bankSelectionOuterButtonSpreadPercent, bankSelectionButtonHeightPercent, selectMouseKeyDropButton, contentPane);

		Image disabledImage = loader.getImage("unavailable.jpg");
		disabledImage = GUITools.changeImageSizeByJpanelSize(disabledImage, bankSelectionSizePercentWidth, -1, contentPane);
		ImageIcon disabledIcon = new ImageIcon(disabledImage);
		for(JButton button: bankSelectionButtons){
			button.setDisabledIcon(disabledIcon);
		}

		GUITools.addButtonsWithActionListener(backButtonArray, this, contentPane);
		GUITools.addButtonsWithActionListener(bankSelectionButtons, this, contentPane);

		contentPane.add(background);
	}

	private void displayNextChoice (int addAmount) throws IOException{
		currentChoiceIndex += addAmount;

		if(choiceNames != null && choiceNames.length > 0){
			String localDirStringBase = choiceStringBase.substring(0, choiceStringBase.lastIndexOf(File.separator));
			loader.setLocalDir(localDirStringBase);
			loader.setLocalURLDir(localDirStringBase.replace(File.separator, "/"));

			Container contentPane = getContentPane();
			if(currentChoiceIndex >= choiceNames.length){
				currentChoiceIndex = 0;
			}
			if(currentChoiceIndex < 0 ){
				currentChoiceIndex = choiceNames.length - 1;
			}
			String currentChoiceString = choiceNames[currentChoiceIndex];
			String replacementString = choiceStringBase.substring(choiceStringBase.lastIndexOf(File.separator) + 1);
			Image currentChoiceImage = loader.getImage(replacementString.replace("%", currentChoiceString));
			currentChoiceImage = GUITools.changeImageSizeByJpanelSize(currentChoiceImage, sizePercentChoiceImage, -1, contentPane);
			currentChoice.setIcon(new ImageIcon(currentChoiceImage));
			GUITools.setComponentSizeToIcon(currentChoice);
			GUITools.setComponentLocation(distanceFromLeftChoiceImage, distanceFromTopChoiceImage, currentChoice, contentPane);
		}
	}

	private void setUpArrowButtons() throws IOException {
		loader.setLocalDir("5-createprofile" + File.separator + "buttons");
		loader.setLocalURLDir("5-createprofile/buttons");

		Container contentPane = getContentPane();

		Image arrowButtonLeftImage = loader.getImage("buttonLeft.jpg");
		GUITools.setImageToButton(arrowButtonLeftImage, buttonArrowsWidthPercent, -1, leftArrowButton, contentPane);
		GUITools.setComponentLocation(50-distanceFromCenterArrowButtons, distanceFromTopArrowButtons, leftArrowButton, contentPane);

		Image arrowButtonRightImage = loader.getImage("buttonRight.jpg");
		GUITools.setImageToButton(arrowButtonRightImage, buttonArrowsWidthPercent, -1, rightArrowButton, contentPane);
		GUITools.setComponentLocation(50+distanceFromCenterArrowButtons, distanceFromTopArrowButtons, rightArrowButton, contentPane);
	}
	
	private void setUpBackButton() throws IOException {
		loader.setLocalDir("5-createprofile" + File.separator + "buttons");
		loader.setLocalURLDir("5-createprofile/buttons");

		Container contentPane = getContentPane();

		Image backButtonImage = loader.getImage("back.jpg");
		GUITools.setImageToButton(backButtonImage, buttonBackWidthPercent, -1, backButton, contentPane);
		GUITools.setComponentLocation(distanceFromLeftBackButton, distanceFromTopBackButton, backButton, contentPane);

	}

	long lastButtonPress = System.currentTimeMillis();

	@Override
	public void actionPerformed(ActionEvent e) {
		if(System.currentTimeMillis() - lastButtonPress > 10){
			lastButtonPress = System.currentTimeMillis();
			Object source = e.getSource();
			if(source == normalButton){
				setNormal();
				clearPanels();
				try {
					clearPanels();
					setUpSpotSelectionScreen();
				} catch (IOException e1) {
				}
			}else if(source == leftArrowButton){
				try {
					displayNextChoice(-1);
				} catch (IOException e1) {
				}
			}else if(source == rightArrowButton){
				try {
					displayNextChoice(1);
				} catch (IOException e1) {
				}
			}else if(source == selectSpotButton){
				try {
					setUpEquiptmentSelectionArray();
					clearPanels();
					setUpEquiptmentSelectionScreen();
				} catch (IOException e1) {
				}
			}else if(source == selectEquiptmentButton){
				try {
					setUpFishSelectionArray();
					clearPanels();
					setUpFishSelectionScreen();
				} catch (IOException e1) {
				}
			}else if(source == selectFishButton){
				try{
					setFishSelection();
					clearPanels();
					setupBankChoiceScreen();
				}catch (Exception e1){
				}
			}else if(source == saveProfileButton){
				try{
				}catch (Exception e1){
				}
			}else if(source == setNameButton){
				String nameText = this.nameTextField.getText();
				if(nameText != null && !nameText.isEmpty()){
					this.name = nameText.replaceAll("&", "");
					saveProfile();
					GUIManager.guiStatus = 1;
					this.dispose();
				}else{
					nameTextField.setBackground(noNameBackgroundColor);
					nameTextField.setForeground(noNameForegroundColor);
				}
			}else if(source == selectBankBoothButton || source == selectDepositBoxButton || source == selectMouseKeyDropButton || source == selectNormalDropButton){
				setDisposeMethod(source);
				try {
					clearPanels();
					setUpSaveNameScreen();
				} catch (IOException e1) {
				}
			}else if(source == backButton){
				this.dispose();
				GUIManager.guiStatus = 1;
			}
			this.revalidate();
			this.repaint();
		}
	}

	private void saveProfile() {
		if(normal){
			NonProgressiveProfileInformation profile = new NonProgressiveProfileInformation(selectedAreaName, selectedEquiptmentName, new String[] {selectedLootName}, bankMethod, this.name);
			GUIManager.loader.saveProfile(profile);
		}
	}

	private void setDisposeMethod(Object source) {
		if(source == this.selectBankBoothButton){
			this.bankMethod = 0;
		}else if(source == this.selectDepositBoxButton){
			this.bankMethod = 1;
		}else if(source == this.selectNormalDropButton){
			this.bankMethod = 2;
		}else if(source == this.selectMouseKeyDropButton){
			this.bankMethod = 3;
		}

	}

	private void setFishSelection() {
		if(currentChoiceIndex < loots.length){
			selectedLootName = loots[currentChoiceIndex].getName();
		}
	}

	private void setNormal() {
		this.normal = true;
	}

	private void setUpFishSelectionArray() {
		if(selectedArea != null && equiptments.length > currentChoiceIndex){
			fishingEquiptment selected = equiptments[currentChoiceIndex];
			if(selected != null){
				selectedEquiptmentName = selected.getName();
				String name = selected.getName();
				loots = selectedArea.getPossibleLoot(name);
				boolean arrowsAreVisible = loots.length > 1;
				this.leftArrowButton.setVisible(arrowsAreVisible);
				this.rightArrowButton.setVisible(arrowsAreVisible);
			}
		}else{
			throwError("Equiptment List Could Not Be Loaded Please Contact Newbotterftw.");
		}
	}

	private void setUpEquiptmentSelectionArray() {
		if(areas.length > currentChoiceIndex){
			selectedArea = areas[currentChoiceIndex];
			if(selectedArea != null){
				selectedAreaName = selectedArea.getName();
				equiptments = selectedArea.getPossibleEquiptmentNoDuplicates();
				boolean arrowsAreVisible = equiptments.length > 1;
				this.leftArrowButton.setVisible(arrowsAreVisible);
				this.rightArrowButton.setVisible(arrowsAreVisible);
			}
		}else{
			throwError("Area List Could Not Be Loaded Please Contact Newbotterftw.");
		}
	}

	private void throwError(String message) {
		JOptionPane pane = new JOptionPane(message);
		pane.setVisible(true);
	}
}
