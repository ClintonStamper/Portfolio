package scripts.fisher.classes;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class fishingSpot {
	/**
	 * 
	 */
	public static int baseSpotID = 1530;

	private int spotID = -1;

	private String option = null;

	private boolean badSpot = true;
	
	private fishingLoot[] possibleLoot = null;
	
	private fishingEquiptment[] possibleEquiptment = null;
	
	private String name;
	
	public fishingSpot(File inputFile, int spotIDAdjustment){
		if(inputFile != null){
			name = inputFile.getName();
			if(name != null){
				name = name.replaceAll(".txt", "");
			}
		}
		this.spotID = fishingSpot.baseSpotID + spotIDAdjustment;
		try {
			Scanner input = new Scanner(inputFile);
			while(input.hasNextLine()){
				String label = input.nextLine();
				if(label.equalsIgnoreCase("id")){
					this.setSpotID(input.nextInt());
				}else if(label.equalsIgnoreCase("option")){
					if(input.hasNextLine()){
						this.setOption(input.nextLine().replaceAll("\"", ""));
					}
				}else if(label.equalsIgnoreCase("equiptment")){
					this.setPossibleEquiptment(readEquiptment(input, inputFile));
				}else if(label.equalsIgnoreCase("badspot")){
					if(input.hasNextBoolean()){
						this.setBadSpot(input.nextBoolean());
					}
				}else if(label.equalsIgnoreCase("loot")){
					this.setPossibleLoot(readLoots(input, inputFile));
				}
			}
			input.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	} 
	
	private fishingLoot[] readLoots(Scanner fileInput, File currentFile) {
		fishingLoot[] result = null;
		String current = fileInput.hasNextLine() ? fileInput.nextLine() : "";

		String directory = currentFile.getAbsolutePath();
		String baseDirectory = directory.substring(0,directory.indexOf(File.separator + "spot"));
		String targetDirectory = baseDirectory + File.separator + "loot" + File.separator;

		ArrayList<fishingLoot> loots = new ArrayList<fishingLoot> ();
		String lootname = null;
		while(!current.equalsIgnoreCase("end") && !current.isEmpty()){
			lootname = current;
			if(lootname != null){
				String filePath = targetDirectory + lootname + ".txt";
				File lootFile = new File(filePath);

				fishingLoot loot = new fishingLoot(lootFile);
				loots.add(loot);

				lootname = null;
			}
			current = fileInput.hasNextLine() ? fileInput.nextLine() : "";
		}

		result = new fishingLoot[loots.size()];
		for(int i = 0 ; i < result.length && i < loots.size() ; i++){
			result[i] = loots.get(i);
		}
		return result;
	}
	
	private fishingEquiptment[] readEquiptment(Scanner fileInput, File currentFile) {
		fishingEquiptment[] result = null;
		String current = fileInput.hasNextLine() ? fileInput.nextLine() : "";

		String directory = currentFile.getAbsolutePath();
		String baseDirectory = directory.substring(0,directory.indexOf(File.separator + "spot"));
		String targetDirectory = baseDirectory + File.separator + "equiptment" + File.separator;

		ArrayList<fishingEquiptment> equiptments = new ArrayList<fishingEquiptment> ();
		String equiptmentname = null;
		while(!current.equalsIgnoreCase("end") && !current.isEmpty()){
			equiptmentname = current;
			if(equiptmentname != null){
				String filePath = targetDirectory + equiptmentname + ".txt";
				File equiptmentFile = new File(filePath);

				fishingEquiptment equiptment = new fishingEquiptment(equiptmentFile);
				equiptments.add(equiptment);

				equiptmentname = null;
			}
			current = fileInput.hasNextLine() ? fileInput.nextLine() : "";
		}

		result = new fishingEquiptment[equiptments.size()];
		for(int i = 0 ; i < result.length && i < equiptments.size() ; i++){
			result[i] = equiptments.get(i);
		}
		return result;
	}

	public int getSpotID() {
		return spotID;
	}

	public void setSpotID(int spotID) {
		this.spotID = spotID;
	}

	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
	}

	public boolean isBadSpot() {
		return badSpot;
	}

	public void setBadSpot(boolean badSpot) {
		this.badSpot = badSpot;
	}

	public fishingLoot[] getPossibleLoot() {
		return possibleLoot;
	}

	public void setPossibleLoot(fishingLoot[] possibleLoot) {
		this.possibleLoot = possibleLoot;
	}

	public fishingEquiptment[] getPossibleEquiptment() {
		return possibleEquiptment;
	}

	public void setPossibleEquiptment(fishingEquiptment[] possibleEquiptment) {
		this.possibleEquiptment = possibleEquiptment;
	}
	
	public String getName(){
		return this.name;
	}
	
}