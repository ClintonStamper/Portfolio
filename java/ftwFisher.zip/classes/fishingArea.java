package scripts.fisher.classes;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import org.tribot.api2007.types.RSArea;
import org.tribot.api2007.types.RSTile;

/*
 * Custom classes
 */
public class fishingArea {


	/**
	 * 
	 */
	private RSArea bankArea = null;
	private RSArea fishArea = null;
	private RSArea walkArea = null;

	private boolean useBankAPI;

	private boolean mustDrop = false;

	private boolean hasDepositBox;

	private fishingSpot[] spots;

	private String readableName;

	private String name;

	@Override
	public String toString(){
		String result = "";
		result += this.readableName;
		return result;
	}

	public fishingArea(File fileToRead){
		if(fileToRead != null){
			this.name = fileToRead.getName();
			if(this.name != null){
				this.name = this.name.replaceAll(".txt", "");
				try {
					Scanner fileInput = new Scanner(fileToRead);
					while(fileInput.hasNextLine()){
						String next = fileInput.nextLine();
						if(next.equalsIgnoreCase("bank")){
							RSArea bankArea = interpretArea(fileInput);
							this.bankArea = bankArea;
						}else if(next.equalsIgnoreCase("fish")){
							RSArea fishArea = interpretArea(fileInput);
							this.fishArea = fishArea;
						}else if(next.equalsIgnoreCase("walk")){
							RSArea walkArea = interpretArea(fileInput);
							this.walkArea = walkArea;
						}else if(next.equalsIgnoreCase("spots")){
							setSpots(interpretSpots(fileInput, fileToRead));
						}else if(next.equalsIgnoreCase("API")){
							if(fileInput.hasNextBoolean()){
								this.useBankAPI = fileInput.nextBoolean();
							}
						}else if(next.equalsIgnoreCase("deposit")){
							if(fileInput.hasNextBoolean()){
								this.hasDepositBox = fileInput.nextBoolean();
							}
						}else if(next.equalsIgnoreCase("name")){
							if(fileInput.hasNextLine()){
								this.readableName = fileInput.nextLine();
							}
						}
					}
					fileInput.close();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
				if(bankArea == null){
					this.setMustDrop(true);
				}
			}
		}
	}
	private fishingSpot[] interpretSpots(Scanner fileInput, File currentFile) {
		fishingSpot[] result = null;

		String pattern = "[a-zA-Z]+\\p{Space}\\W\\d+";
		String current = fileInput.hasNextLine() ? fileInput.nextLine() : "";
		if(currentFile != null){
			String directory = currentFile.getAbsolutePath();
			if(directory != null){
				int index = directory.indexOf(File.separator + "area");
				if(index != -1){
					String baseDirectory = directory.substring(0,index);
					if(baseDirectory != null){
						String targetDirectory = baseDirectory + File.separator + "spot" + File.separator;
						if(targetDirectory != null){
							ArrayList<fishingSpot> spots = new ArrayList<fishingSpot> ();
							String spotname = null;
							int spotIDDifference = Integer.MAX_VALUE;
							while(current.matches(pattern)){
								String[] parts = current.split(" ", 2);
								if(parts.length == 2){
									spotIDDifference = Integer.parseInt(parts[1]);
									spotname = parts[0];
								}

								if(spotname != null && spotIDDifference < Integer.MAX_VALUE ){
									String filePath = targetDirectory + spotname + ".txt";
									File spotFile = new File(filePath);

									fishingSpot spot = new fishingSpot(spotFile, spotIDDifference);
									spots.add(spot);

									spotname = null;
									spotIDDifference = Integer.MAX_VALUE;
								}
								current = fileInput.nextLine();
							}

							result = new fishingSpot[spots.size()];
							for(int i = 0 ; i < result.length && i < spots.size() ; i++){
								result[i] = spots.get(i);
							}
						}
					}
				}
			}
		}
		return result;
	}

	private RSArea interpretArea(Scanner fileInput) {
		String pattern = "\\d+[x]{1}\\d+[y]{1}\\d+[z]{1}";
		String current = fileInput.hasNextLine() ? fileInput.nextLine() : "";
		ArrayList<RSTile> areaTiles = new ArrayList<RSTile>();
		while(current.matches(pattern)){
			int xIndex = current.indexOf('x');
			int yIndex = current.indexOf('y');
			int zIndex = current.indexOf('z');
			int x = Integer.parseInt(current.substring(0, xIndex));
			int y = Integer.parseInt(current.substring(xIndex+1, yIndex));
			int z = Integer.parseInt(current.substring(yIndex+1, zIndex));
			if(x >= 0 && y >= 0 && x >= 0){
				RSTile tileToAdd = new RSTile(x, y, z);
				areaTiles.add(tileToAdd);
			}
			if(fileInput.hasNextLine()){
				current = fileInput.nextLine();
			}else{
				current = "";
			}
		}
		RSTile[] areaTileArray = new RSTile[areaTiles.size()];
		for(int i = 0 ; i < areaTileArray.length && i < areaTiles.size() ; i++){
			areaTileArray[i] = areaTiles.get(i);
		}
		RSArea result = areaTileArray != null  && areaTileArray.length > 0 ? new RSArea(areaTileArray) : null;
		return result;
	}

	public fishingEquiptment[] getPossibleEquiptment(){
		fishingEquiptment[] result = {};

		ArrayList<fishingEquiptment> equiptment = new ArrayList<>();
		if(spots != null){
			for(fishingSpot spot : spots){
				result = spot.getPossibleEquiptment();
				for(fishingEquiptment equipt : result){
					equiptment.add(equipt);
				}
			}
		}

		result = equiptment.toArray(result);

		return result;
	}

	/**
	 * @return the name
	 */
	public String getReadableName() {
		return readableName;
	}

	/**
	 * @param name the name to set
	 */
	public void setReadableName(String name) {
		this.readableName = name;
	}

	/**
	 * @return the hasDepositBox
	 */
	public boolean isHasDepositBox() {
		return hasDepositBox;
	}

	/**
	 * @param hasDepositBox the hasDepositBox to set
	 */
	public void setHasDepositBox(boolean hasDepositBox) {
		this.hasDepositBox = hasDepositBox;
	}

	/**
	 * @return the mustDrop
	 */
	public boolean isMustDrop() {
		return mustDrop;
	}

	/**
	 * @param mustDrop the mustDrop to set
	 */
	public void setMustDrop(boolean mustDrop) {
		this.mustDrop = mustDrop;
	}

	/**
	 * @return the useBankAPI
	 */
	public boolean isUseBankAPI() {
		return useBankAPI;
	}

	/**
	 * @param useBankAPI the useBankAPI to set
	 */
	public void setUseBankAPI(boolean useBankAPI) {
		this.useBankAPI = useBankAPI;
	}
	public fishingSpot[] getSpots() {
		return spots;
	}
	public void setSpots(fishingSpot[] spots) {
		this.spots = spots;
	}

	public String getName(){
		return this.name;
	}
	public fishingEquiptment[] getPossibleEquiptmentNoDuplicates() {
		fishingEquiptment[] result = getPossibleEquiptment();
		ArrayList<fishingEquiptment> equiptmentArray = new ArrayList<>();

		for(fishingEquiptment equiptment : result){
			boolean add = true;
			for(int i = 0 ; i < equiptmentArray.size() ; i++){
				fishingEquiptment comparisonCurrent = equiptmentArray.get(i);
				if(comparisonCurrent.getName().equalsIgnoreCase(equiptment.getName())){
					add = false;
				}
			}
			if(add){
				equiptmentArray.add(equiptment);
			}
		}
		return equiptmentArray.toArray(new fishingEquiptment[0]);
	}
	public fishingLoot[] getPossibleLoot(String equiptmentName) {
		fishingLoot[] loots = {};
		ArrayList<fishingLoot> lootArray = new ArrayList<>();

		for(fishingSpot spot : spots){
			fishingEquiptment[] currentSpotEquiptment = spot.getPossibleEquiptment();
			boolean addLoot = false;
			for(fishingEquiptment equiptment : currentSpotEquiptment){
				if(equiptment.getName().equalsIgnoreCase(equiptmentName)){
					addLoot = true;
				}
			}

			if(addLoot){
				loots = spot.getPossibleLoot();
				for(fishingLoot loot : loots){
					lootArray.add(loot);
				}
			}
		}
		return lootArray.toArray(new fishingLoot[0]);
	}
	public boolean isThereBankBooth() {
		return !mustDrop;
	}
	public boolean isThereDepositBox() {
		// TODO Auto-generated method stub
		return !mustDrop && hasDepositBox;
	}

	public RSArea getWalkArea() {
		return walkArea;
	}

	public RSArea getFishArea() {
		return fishArea;
	}

	public RSArea getBankArea() {
		return bankArea;
	}
}