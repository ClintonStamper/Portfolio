package scripts.fisher.classes;

public class NonProgressiveProfileInformation {
	
	private final String areaName;
	private final String equiptmentName;
	private String[] lootsNames;
	private final int bankOption;
	private final String profileName;
	
	public NonProgressiveProfileInformation(String area, String equipt, String[] loots, int bankOption, String profileName){
		this.areaName = area;
		this.equiptmentName = equipt;
		this.setLootsNames(loots);
		this.profileName = profileName;
		this.bankOption = bankOption;
	}

	public String getProfileName() {
		return profileName;
	}

	public boolean isDropMouseKeys() {
		return bankOption == 3;
	}

	public boolean useDepositBox() {
		return bankOption == 1;
	}

	public boolean useBoothBanker() {
		return bankOption == 0;
	}

	public String getAreaName() {
		return areaName;
	}

	public String getEquiptmentName() {
		return equiptmentName;
	}

	public String[] getLootsNames() {
		return lootsNames;
	}

	public void setLootsNames(String[] loot) {
		this.lootsNames = loot;
	}
	
	@Override
	public String toString(){
		String result = "";
		result += profileName;
		return result;
	}

	public String getLossListFormatted() {
		String result = "";
		
		for(int i = 0 ; i < lootsNames.length ; i++){
			String loot = lootsNames[i];
			result += loot;
			if(lootsNames.length - i > 1){
				result += ",";
			}
		}
		return result;
	}

	public int getBankOption() {
		return bankOption;
	}

}
