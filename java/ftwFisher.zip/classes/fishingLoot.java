package scripts.fisher.classes;

import java.io.File;

public class fishingLoot extends fishingItem{

	public fishingLoot(File inputFile) {
		super(inputFile);
	}

}
