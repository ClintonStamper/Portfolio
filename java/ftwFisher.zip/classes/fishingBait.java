package scripts.fisher.classes;

import java.io.File;

public class fishingBait extends fishingItem{
	
	public fishingBait(File inputFile) {
		super(inputFile);
	}

	private boolean useBait = true;

	public boolean shouldUse() {
		return useBait;
	}

	public void setUseBait(boolean useBait) {
		this.useBait = useBait;
	}
	
}
