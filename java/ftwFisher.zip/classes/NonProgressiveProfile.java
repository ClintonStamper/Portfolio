package scripts.fisher.classes;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import org.tribot.api2007.types.RSNPC;
import org.tribot.util.Util;

public class NonProgressiveProfile extends NonProgressiveProfileInformation {

	private final fishingArea area;
	private final fishingEquiptment equiptment;
	private final fishingLoot[] loots;
	private final fishingSpot[] spots;

	private final String baseDirForPresets = Util.getWorkingDirectory() + File.separator + "ftwfisher" + File.separator + "presets" + File.separator;
	
	@Override
	public String toString(){
		String result = "";
		result += "Fishing in " + area + " with " + equiptment + " at the spots " + Arrays.toString(spots) + " for loots " + Arrays.toString(loots);
		return result;
		
	}

	public NonProgressiveProfile(String areaName, String equiptmentName, String[] lootsNames, int bankOption, String profileName) {
		super(areaName, equiptmentName, lootsNames, bankOption, profileName);
		this.area = makeArea(areaName);
		this.equiptment = makeEquiptment(equiptmentName);
		this.loots = makeLoots(lootsNames);
		this.spots = findSpot();
	}

	public NonProgressiveProfile(NonProgressiveProfileInformation incomingInfo){
		super(incomingInfo.getAreaName(), incomingInfo.getEquiptmentName(), incomingInfo.getLootsNames(), incomingInfo.getBankOption(), incomingInfo.getProfileName());

		this.area = makeArea(incomingInfo.getAreaName());
		this.equiptment = makeEquiptment(incomingInfo.getEquiptmentName());
		this.loots = makeLoots(incomingInfo.getLootsNames());
		this.spots = findSpot();
	}

	private fishingArea makeArea(String areaName) {
		fishingArea result = null;
		String areaDirectory = baseDirForPresets + "area" + File.separator + areaName + ".txt";
		File areaFile = new File(areaDirectory);
		result = new fishingArea(areaFile);
		return result;
	}

	private fishingEquiptment makeEquiptment(String equiptmentName) {
		fishingEquiptment result = null;

		if(this.area != null){
			fishingEquiptment[] equiptments = this.area.getPossibleEquiptment();
			for(fishingEquiptment equipt : equiptments){
				if(equipt.getName().equalsIgnoreCase(equiptmentName)){
					result = equipt;
					break;
				}
			}
		}

		return result;
	}

	private fishingLoot[] makeLoots(String[] lootsNames) {
		ArrayList<fishingLoot> result = new ArrayList<>();
		if(this.area != null && this.equiptment != null){

			fishingLoot[] possible = this.area.getPossibleLoot(this.equiptment.getName());

			for(fishingLoot current : possible){
				String currentName = current.getName();
				for(String name : lootsNames){
					if(name.equalsIgnoreCase(currentName)){
						result.add(current);
						break;
					}
				}
			}
		}

		return result.size() > 0 ? result.toArray(new fishingLoot[0]) : null;
	}

	private fishingSpot[] findSpot() {
		ArrayList<fishingSpot> result = new ArrayList<>();
		if(this.equiptment != null && this.loots != null && this.area != null){
			fishingSpot[] possible = this.area.getSpots();
			for(fishingSpot spot : possible){
				boolean addBasedOnEquiptment = false; 
				fishingEquiptment[] equiptmentsFromSpot = spot.getPossibleEquiptment();
				for(fishingEquiptment equiptmentFromSpot : equiptmentsFromSpot){
					if(equiptmentFromSpot.equals(equiptment)){
						addBasedOnEquiptment = true;
					}
				}
				boolean addBasedOnLoot = false;
				fishingLoot[] lootsFromSpot = spot.getPossibleLoot();
				for(fishingLoot lootFromSpot : lootsFromSpot){
					for(fishingLoot lootFromProfile : loots){
						addBasedOnLoot = addBasedOnLoot || lootFromProfile.equals(lootFromSpot);
					}
				}
				if(addBasedOnEquiptment && addBasedOnLoot){
					result.add(spot);
				}
			}
		}
		return result.toArray(new fishingSpot[0]);
	}

	public fishingArea getArea() {
		return this.area;
	}

	public fishingLoot[] getLoots() {
		return this.loots;
	}

	public fishingSpot[] getSpots() {
		return this.spots;
	}

	public fishingEquiptment getEquiptment() {
		return this.equiptment;
	}

	public int[] getDontDropIDS() {
		ArrayList<Integer> results = new ArrayList<>();
		if(this.equiptment != null){
			results.add(this.equiptment.getId());
			fishingBait[] baits = this.equiptment.getBaits();
			if(baits != null){
				for(fishingBait bait : baits){
					results.add(bait.getId());
				}
			}
		}

		int[] result = new int[results.size()];
		for(int i = 0 ; i < results.size() ; i++){
			result[i] = results.get(i);
		}

		return result;
	}

	public int[] getDontBankIDS() {
		ArrayList<Integer> results = new ArrayList<>();
		if(this.equiptment != null){
			results.add(this.equiptment.getId());
			fishingBait[] baits = this.equiptment.getBaits();
			if(baits != null){
				for(fishingBait bait : baits){
					results.add(bait.getId());
				}
			}
		}

		int[] result = new int[results.size()];
		for(int i = 0 ; i < results.size() ; i++){
			result[i] = results.get(i);
		}

		return result;
	}

	public int[] getSpotIDS() {
		ArrayList<Integer> results = new ArrayList<>();

		if(this.spots != null){
			for(fishingSpot spot : spots){
				if(spot != null){
					results.add(spot.getSpotID());
				}
			}
		}

		int[] result = new int[results.size()];
		for(int i = 0 ; i < result.length ; i++){
			result[i] = results.get(i);
		}

		return result;
	}

	public String getSpotOption(RSNPC targetSpot) {
		String result = "";
		if(this.spots != null){
			if(targetSpot != null){
				String[] actions = targetSpot.getActions();
				if(actions != null){
					for(int i = 0 ; i < spots.length && result.isEmpty(); i++){
						fishingSpot currentSpot = spots[i];
						if(currentSpot != null){
							String spotAction = currentSpot.getOption();
							if(spotAction != null){
								for(String action : actions){
									if(action != null){
										if(action.equalsIgnoreCase(spotAction)){
											result = action;
											break;
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return result;
	}
}
