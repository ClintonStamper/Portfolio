package scripts.fisher.classes;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.tribot.api2007.Interfaces;
import org.tribot.api2007.Inventory;
import org.tribot.api2007.types.RSInterfaceChild;
import org.tribot.api2007.types.RSInterfaceComponent;
import org.tribot.api2007.types.RSInterfaceMaster;
import org.tribot.api2007.types.RSItem;
import org.tribot.api2007.types.RSItemDefinition;

public class fishingItem {

	private int id;

	private String readableName;
	
	private String name;
	
	private final int EQUIPTMENT_MASTER_INTERFACE_INDEX = 387;
	private final int EQUIPTMENT_MAINHAND_CHILD_INDEX = 9;
	private final int EQUIPTMENT_BUTTON_MASTER_INTERFACE_INDEX = 387;
	private final int EQUIPTMENT_BUTTON_MAINHAND_CHILD_INDEX = 9;

	@Override
	public String toString(){
		String result = "";
		result += this.readableName;
		return result;
	}


	public fishingItem(File inputFile){
		if(inputFile != null){
			this.name = inputFile.getName();
			if(this.name != null){
				this.name = this.name.replaceAll(".txt", "");
				Scanner input = null;
				try {
					input = new Scanner(inputFile);
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
				if(input != null){
					while(input.hasNextLine()){
						String current = input.nextLine();
						if(current.equalsIgnoreCase("id")){
							setId(input.nextInt());
						}else if(current.equalsIgnoreCase("name")){
							setReadableName(input.nextLine());
						}
					}
				}
				input.close();
			}
		}
	}



	/**
	 * @return the name
	 */
	public String getReadableName() {
		return readableName;
	}



	/**
	 * @param name the name to set
	 */
	private void setReadableName(String name) {
		this.readableName = name;
	}



	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	
	public String getName(){
		return this.name;
	}



	/**
	 * @param id the id to set
	 */
	private void setId(int id) {
		this.id = id;
	}

	@Override
	public boolean equals(Object obj){
		boolean result = false;
		if(obj instanceof fishingItem){
			fishingItem itemToCompareTo = (fishingItem) obj;
			result = this.getName().equalsIgnoreCase(itemToCompareTo.getName());
		}
		return result;
	}
	
	public boolean carryingItem() {
		boolean allInterfacesValid = false;
		boolean result = this.getId() == -1;
		if(!result){
			RSItem[] all = Inventory.getAll();
			result = checkItemArray(all, result);
			if(!result){
				RSInterfaceMaster equiptmentScreen = Interfaces.get(EQUIPTMENT_MASTER_INTERFACE_INDEX);
				RSInterfaceChild equiptmentButton = Interfaces.get(EQUIPTMENT_BUTTON_MASTER_INTERFACE_INDEX, EQUIPTMENT_BUTTON_MAINHAND_CHILD_INDEX);
				if(equiptmentScreen != null && equiptmentButton != null){
					if(equiptmentButton.isHidden()){
						return true;
					}
					RSInterfaceChild mainHandInterface = equiptmentScreen.getChild(EQUIPTMENT_MAINHAND_CHILD_INDEX);
					if(mainHandInterface != null){
						RSInterfaceComponent mainHandComponent = mainHandInterface.getChild(1);
						if(mainHandComponent != null){
							int id = mainHandComponent.getComponentItem();
							if(id != -1){
								result = id == this.getId();
							}
							allInterfacesValid = true;
						}
					}
				}
			}
		}
		result = result || !allInterfacesValid;
		return result;
	}


	private boolean checkItemArray(RSItem[] all, boolean equiptmentInInv) {
		if(all != null){
			for(RSItem item : all){
				if(item != null){
					RSItemDefinition itemDef = item.getDefinition();
					if(itemDef != null){
						int itemID = itemDef.getID();
						equiptmentInInv = equiptmentInInv || itemID == this.getId();
					}
				}
			}
		}
		return equiptmentInInv;
	}
	
	public boolean idMatches(int itemID) {
		boolean result = this.getId() == itemID;
		return result;
	}
	
}
