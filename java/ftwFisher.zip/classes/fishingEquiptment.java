package scripts.fisher.classes;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import org.tribot.api2007.Inventory;
import org.tribot.api2007.types.RSItem;
import org.tribot.api2007.types.RSItemDefinition;

public class fishingEquiptment extends fishingItem{

	private fishingBait[] baits = null;

	public fishingEquiptment(File inputFile){
		super(inputFile);
		try {
			Scanner scanner = new Scanner(inputFile);
			while(scanner.hasNextLine() && baits == null){
				if(scanner.nextLine().equalsIgnoreCase("bait")){
					baits = readBaits(scanner, inputFile);
				}
			}
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}


	private fishingBait[] readBaits(Scanner fileInput, File currentFile) {
		fishingBait[] result = null;
		String current = fileInput.hasNextLine() ? fileInput.nextLine() : "";

		String directory = currentFile.getAbsolutePath();
		String baseDirectory = directory.substring(0,directory.indexOf(File.separator + "equiptment"));
		String targetDirectory = baseDirectory + File.separator + "bait" + File.separator;

		ArrayList<fishingBait> baits = new ArrayList<fishingBait> ();
		String baitname = null;
		while(!current.equalsIgnoreCase("end") && !current.isEmpty()){
			baitname = current;
			if(baitname != null){
				String filePath = targetDirectory + baitname + ".txt";
				File baitFile = new File(filePath);

				fishingBait bait = new fishingBait(baitFile);
				baits.add(bait);

				baitname = null;
			}
			current = fileInput.hasNextLine() ? fileInput.nextLine() : "";
		}

		result = new fishingBait[baits.size()];
		for(int i = 0 ; i < result.length && i < baits.size() ; i++){
			result[i] = baits.get(i);
		}
		return result;
	}

	public fishingBait[] getBaits() {
		return baits;
	}

	public boolean carryingItemAndBaits() {
		fishingItem equiptmentAsItem = this;
		boolean result = equiptmentAsItem.carryingItem();
		RSItem[] all = Inventory.getAll();
		boolean baitInInv = this.baits == null || this.baits.length == 0;
		if(this.baits != null){
			for(fishingBait bait : this.baits){
				if(all != null){
					for(RSItem item : all){
						if(item != null && bait != null){
							RSItemDefinition itemDef = item.getDefinition();
							if(itemDef != null){
								int itemID = itemDef.getID();
								if(itemID != -1 && bait.getId() != -1){
									baitInInv = baitInInv || itemID == bait.getId();
								}
							}
						}
					}
				}
			}
		}
		result = result && baitInInv;
		return result;
	}


	public boolean idMatchesAnyEquiptment(int itemID) {
		boolean result = this.getId() == itemID;
		if(!result){
			if(this.baits != null){
				for(fishingBait bait : baits){
					if(bait != null){
						int baitID = bait.getId();
						if(baitID != -1){
							result = result || baitID == itemID;
						}
					}
				}
			}
		}
		return result;
	}
}
